const r_none =  -1 
const rscIdx_pig = 0
const r_pig = 0

const rscIdx_tiger = 1
const r_tiger = 1

const rscIdx_cat = 2 
const r_cat = 2

const r_cat2 = 3
const r_cat3 = 4
//const r_cat4 = 5
const r_cat_red = 6 //red

const r_dog = 7

//--------------------
//reflect없앨 수 있는 petBall
const r_diamond = 8
//------------------- 


const r_bullet_01 = 10
const r_bullet = 10
const r_enemy_bullet =11
const r_enemy_guard =11

const r_defense_ball = 12

const r_paddle_bullet = 13

//----------
const rscIdx_rock_01 = 20
const r_rock_01 = 20
const r_rock_reflect  = 21
const r_rock_breakable = 22

const r_rock_eat  = 23 
const r_rock_hole = 23 
const r_rock_wrld_bound = 24

//----------
const r_rock_reflect2 = 25
const r_rock_reflect3 = 26
const r_rock_reflect4 = 27 //green

const r_rock_reflect_invincible = 28 //yellow

//----------
const r_rock_float_anchor = 29

/*
const r_rock_itembox = 29
const r_rock_b2 = 30
const r_rock_b3 = 31 
*/

//================
const r_mon1 = 30 
const r_mon2 = 31 
const r_mon2_child = 32 
const r_mon3 = 33 
const r_mon_bull = 34 
const r_mon_redcat = 35 
const r_mon_eye = 36



const r_item_bomb = 50 
const r_item_eye    = 51
const r_item_gun   =  51
const r_item_smaller   = 52
//prize photo
const r_item_photo    = 53
const r_item_classic    = 53
//---- 
const r_item_diamond = 55

const r_item_enemy_bullet_trigger = 56

const r_item_heart = 57

const r_item_double = 58

const r_item_slow    = 59
const r_item_fast    = 60


const r_item_long = 61
const r_item_short = 62


//---------
const r_debris_01 = 70

//--------
const rscIdx_effect_15pt = 100 

const r_wake_monster = 500









const paddleState_normal = 0
const paddleState_long = 1


//=============


const ballstate_move = 0
//----------
const ballstate_link = 2
const ballstate_anchored = 2 
//-----------

const ballstate_move_byExtForce = 3

const ballstate_move_nextCollide = 4 

const ballstate_restore_toAnchor = 5 

const ballstate_link_toNextBall= 6 
const ballstate_move_toDrawBall = 6
const ballstate_drawed_toDrawBall = 6

const ballstate_fallingDown = 7

const ballstate_move_pattern = 8 

const ballstate_up_in_the_air = 9

const ballstate_waitForWake = 10 
const ballstate_sleep = 10

const ballstate_move_toDst = 11 
//목표지점까지 이동 

const ballstate_small_toDeath = 12

const ballstate_tentacle = 13 

//약간 느린 fallingDown
const ballstate_fallingDown2 = 14

const ballstate_bigToNormal = 15

const ballstate_debug = 16



const playMinY = 20

const anchor_max_displace = 5 

//=================
const ball_prop_fixed                 =     0x00000001
const ball_prop_fixedToWrld        =     0x00000001
const ball_prop_static                 =     0x00000001
const ball_prop_fixedToRock       =     0x00000001

const ball_prop_reflect               =     0x00000002
const ball_prop_topLayer            =     0x00000004


const ball_prop_invincible     =     0x00000008
//const ball_prop_helpPet     =     0x00000008


const ball_prop_not_collision_wall =    0x00000010
const ball_prop_not_collision_ball =    0x00000020
const ball_prop_not_gravity         =    0x00000040
//draw하지도 당하지도 않음 
const ball_prop_not_draw           =    0x00000080
//draw[x], attach[x],
const ball_prop_monster             =    0x00000100
const ball_prop_customAttach      =    0x00000200

//anchor를 업데이트 해야 합니다.
const ball_prop_updateAnchor     =    0x00000400
const ball_prop_enemy_bullet      =    0x00000800

const ball_prop_waitFor_drawer     =    0x00001000
const ball_prop_drawee               =    0x00001000

const ball_prop_drawer                  =    0x00002000
const ball_prop_collide_ground        =    0x00004000
const ball_prop_restore_toAnchor    =   0x00008000
const ball_prop_breakable              =   0x00010000
//---
//debris 
const ball_prop_not_interact           =   0x00020000
const ball_prop_not_collide_hole      =   0x00040000
//
const ball_prop_enemy                  =   0x00080000
const ball_prop_attack_player                 =   0x00080000 //<----

const ball_prop_world_bound          =   0x00100000
const ball_prop_waitForWake          =   0x00200000
const ball_prop_not_moveDown      =    0x00400000 
//명시적 moveDown
const ball_prop_moveDown            =    0x00800000 

const ball_prop_dstPos_loop           =    0x01000000 

const ball_prop_attack_enemy         =    0x02000000 //<-----

const ball_prop_itemBox                =    0x04000000 //<-----
//defenseball과 충돌체크X, 파괴X  
const ball_prop_monsterBullet         =    0x08000000 //     





const ball_cmd_moveCircle        = 1

//=========
//script rockType
//--------------
const rock_f    =  0 
const rock_f_r  =  1 
const rock_f_r_b    =  6 
const rock_mh   =  2 
const rock_mh_r =  3 
//-------------
const rock_c   =  4
const rock_c_r =  5
//_breakable
//--------------
//const rock_f_eat  = 7
//const rock_f_hole = 7
//const rock_mh_eat  = 8
//const rock_mh_hole = 8
//-----
const rock_c_r_b  = 9
const rock_mh_r_b =  10 
//-----
const rock_f_r2  = 11  //r2(reflect2)
const rock_mh_r2  = 12  //r2(reflect2)
const rock_mv_r2  = 13  //r2(reflect2)
const rock_c_r2  = 14  //r2(reflect2)

const rock_f_r3  = 15 
const rock_c_r3  = 16 

const rock_f_r4  = 17  
const rock_c_r4  = 18  

const rock_f_r_invincible = 20



//============

//const ball_prop_dynamic    =    0x00000002

const act_idle  = 0
const act_attack = 1
const act_damage = 2  
const act_dead    = 3 
//이동(move) 중에 공격, damage모두 가능


//30s 
// 10초 1단계 , 8초 2단계, 5초(3단계)
const fallingdown_interval_1 = 10000
const fallingdown_interval_2 =  8000
const fallingdown_interval_3 =  5000 


//================
const stageScene_stageBegin = 1
//const stageScene_stageClear  = 2

//================
const appState_home =  0
const appState_play   =  1
const appState_stageClear = 2
const appState_stageFail = 3

//----------------

const homeSubstate_flower = 1  
//const homeSubstate_flower = 1  


const playSubstate_none = 0
const playSubstate_beginStage = 1
const playSubstate_show_stageInfo = 2 //help, targetBall...
const playSubstate_waitForUserStart = 3
const playSubstate_waitForFirePosition = 3
const playSubstate_waitForFire = 4

const playSubstate_play  = 5

const playSubstate_stageEnd_pending = 6 //

const playSubstate_stageProgress = 7
const playSubstate_stageScene = 7

//---------------
const stageClearSubstate_show_prizeImg = 1
const stageClearSubstate_show_ranking = 2




//const stageSubState_loadStageInfo = 2 
//---------------

const stageFail_none = -1
const stageFail_step1 = 0
//ceiling내려오기 
const stageFail_step2 = 1
const stageFail_step3 = 2


//=============
const stageFail_invalidY = 0
const stageFail_timeout = 1


//=============
const  move_none  = 0
const  move_h       = 1 
const  move_v       = 2
const  move_circle   = 3 
const  move_circle2  = 4 //2번 회전 후 이탈

//제자리에서 회전하기 
const move_rot     = 5

const move_byGroup = 6  

const move_byTentacle = 7  



//============

//petBall type
const petType_attach = 0
const petType_save    = 1
const petType_help    = 1


//================
const gameDlg_none = 0
const gameDlg_stageClear = 1
const gameDlg_stageFail   = 2
const gameDlg_noHeart   = 3
const gameDlg_help        = 4
const gameDlg_offline     = 5 

const gameDlg_cutScene = 6


//============
const playKind_match = 0
const playKind_timeout  = 1 //timeout
const playKind_savePet  = 1
//-------------
const playKind_defense = 2

//const playKind_patternEnemy = 2  //timeout


const sound_cat_01 = 0 //match 
const sound_cat_02 = 1
const sound_cat_03 = 2

const sound_dog_01 = 3 //joint - petBall  
const sound_monster_dead = 4 //joint - petBall  

//========
const sound_bomb  = 5
const sound_broken = 6
const sound_good   = 7 // --->item 

const sound_hit    = 8 //도 colli --> rock 
const sound_hit_01    = 9 //도 colli --> rock 
const sound_hit_02    = 10 //도 colli --> rock 
//----------------

//========
//match, monster hit 등
const sound_match_01 = 11
const sound_match_02 = 12
const sound_match_03 = 13
const sound_bullet_fire = 14
const sound_bullet_fire_01 = 15
const sound_bullet_fire_02 = 16


const sound_stage_fail = 17
const sound_stage_clear = 18

//---------------------------





const sound_note_hit = 0
const sound_note_hit01 = 1
const sound_note_hit02 = 2

const sound_note_fire = 3
const sound_note_fire01 = 4
const sound_note_fire02 = 5


const sound_note_broken = 6




const sound_note_do = sound_note_hit
const sound_note_re = sound_note_hit
const sound_note_mi = sound_note_hit01
const sound_note_pa = sound_note_hit01
const sound_note_sol = sound_note_hit01
const sound_note_la = sound_note_hit02
const sound_note_si = sound_note_hit02
const sound_note_do2 = sound_note_hit02

let gUseSoundNoteHit = false 
//---------------------


const touch_guide_step_none = -1
const touch_guide_step_0 = 0
const touch_guide_step_1 = 1
const touch_guide_step_2 = 2
const touch_guide_step_3 = 3
const touch_guide_step_4 = 4
const touch_guide_step_fin = 5

//================
//
//===============
const music_home = 0
const music_play_01 = 1
const music_play_02 = 2
const music_play_03 = 3
const music_play_04 = 4
//------
const music_play_05 = 5
const music_play_monster = 5 

//==============

const move_c_speed_level_1 = 1 
const move_c_speed_level_2 = 2


const move_c_radius_short = 60 
const move_c_radius_mid   = 80
const move_c_radius_long  = 100



//================
const move_pattern_none = 0 
const move_pattern_u = 1
const move_pattern_v = 2

const move_pattern_circle = 3
const move_pattern_circle2 = 12

//const move_pattern_s = 3 
const move_pattern_tri_1 = 4
const move_pattern_tri_2 = 5 

const move_pattern_line = 6
const move_pattern_line_h = 6//수평
const move_pattern_line_v = 7//수직


const move_pattern_diagonal_1 = 8 //rightToLeft
const move_pattern_diagonal_2 = 9 //leftToRight

const move_pattern_wave_h = 10 
const move_pattern_wave_v = 11 

const move_pattern_rect = 13  


//=============
const normal_unknown = 0
const normal_vh = 1


//===============

let paddleW = 100
//   100/375

//컨트롤은 해상도에 따라 변하지 않음 
let controlHeight = 80
let topMenuHeight = 60


let gIsDiamondState = false 


const paddle_normal  =   0
const paddle_long     =   1
const paddle_short     =  2

let gPaddleLengthState = paddle_normal

const gMaxSpeed = 0.4
const gMinSpeed = 0.25





const flowerState_none = 0
const flowerState_waitForUserTouch = 1
const flowerState_watering = 2
const flowerState_growing = 3


const flowerState_blooming = 4
const flowerState_growingEnd = 5
const flowerState_bloomingEnd = 6


//50 stage --> 10장 
const maxPhotoIdx = 9

const worldGravity = 0.0015

let gRankArray = []


//발사후 최소 2초후에 발사가능 
let gFireCoolTime = 2000
let gFireLastT = 0


let _useSoundNote = true 

let gUID

//===============
//android와 확인하기
const _verStr = '1.47'
//===============

let gIsAndroid = true
let gIsDevice   = true
let gDebug = false

let gNetworkCheck = true 

 