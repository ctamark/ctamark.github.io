const aiState_idle = 0
const aiState_attack = 1
const aiState_post_attack = 2
const aiState_damage = 3

const fireState_ready = 0
const fireState_firing = 1  
const fireState_end = 2 //wait for cooltime
const fireState_cooltime = 2 //wait for nextFire
 

class monsterAI {
	
	constructor(ball, attack_interval=10000){
	
	   this.lastAttackT = 0 
	   this.attackInterval = attack_interval //10초 
	   this.ball_id = ball.id 
	   this.ball = ball 
	   this.stateST = 0
	   
	   
	    this.lastFireT = 0 
	  
	   this.lastFrameT = 0
	   this.userFlag = true 
	   
	   this.actState = act_idle
	   
	   this.canSpawn = false 

	   this.isReadyFire   = false
	   
	   this.fireState = 0
	 
	   
	   this.motion = null
	   
	   this.fireCount = 0
	   
	    this.movePattern = move_none
		
		this.movePatternVelocityX = 1.0*0.05
		
		
	         			
	}
	
	
	init(){
		
		
		if(this.ball.level ==2){
			
			this.attackInterval = 10000
			
		}

		if(gPlayKind == playKind_defense){

           //2초간 기다렸다 ready 
           this.isReadyFire   = false

		}
		
		this.fireCount = 0
		
        this.lastAttackT = 0

	}
	
	//actidx를 같이 사용 
	setState(act_idx){
		
		if(act_idx == act_damage){
			
			if(this.ball.rscIdx == r_mon1 || this.ball.rscIdx ==r_mon2 ){
				
				this.ball.iSpriteIdx = 2
			}
			else if(this.ball.rscIdx == r_mon3){
				
				this.ball.iSpriteIdx = 1
			}
			
		    this.actState = act_damage
		    this.stateST = gAppCurT	
			
		}
		else  if(act_idx == act_dead){
						
			if(this.canSpawn){
				let refX = this.ball.pos.x 
	 		    let refY = this.ball.pos.y 

				let userInfo = {rscIdx: this.ball.rscIdx, x: refX, y: refY}
                addGameCmd('monster_spawn', userInfo)			
				
			}			
			else {
	
		        this.ball.setState(ballstate_fallingDown)		
			}
			
		}
				
		
	}
	
	
	update(deltaT){
		
	//	let elapT = gAppCurT -  this.lastAttackT
	
	 if(this.motion != null){
		 
		 this.motion.update()
		 
		  this.ball.pos.x = this.motion.pos.x 				 
		  this.ball.pos.y = this.motion.pos.y 				
	      this.ball.setAnchor(this.ball.pos.x,  this.ball.pos.y)				  
				 
	 }
	 
	 if(this.movePattern != move_none){
	 
	   this.updateMovement(deltaT)
	 
	  }
	 
	 	  
		  if(gPlayKind == playKind_defense){

		     this.update_defenseMon()
		     return
		  }
		  
	
          if(this.ball.rscIdx == r_mon2 || this.ball.rscIdx == r_mon2_child){

             this.update_mon2()

             return          
		  }			  	
		  
		  if(this.ball.rscIdx == r_mon3){
			  
			  this.update_mon3()
			  
			  return 
		  }

	

		  
		    //================
			//r_mon1
			//================
			if(this.actState== act_idle){
																
				if(gAppCurT >= this.lastAttackT + this.attackInterval ){ 
					
					if(gAppState == appState_home){
					
						//attack cmd 				
						 let event = new CustomEvent("monster_fire_bullet", {detail:{id:this.ball_id} })
						 document.dispatchEvent(event)
					   
					}
					else if(gAppState == appState_play && gStageElapsT >= 2000 && gIsShowGameDlg== false){
						
						//level 1은 발사 없음 
						//if(this.ball.level >= 2){						
						  //attack cmd 				
						   let event = new CustomEvent("monster_fire_bullet", {detail:{id:this.ball_id} })
						   document.dispatchEvent(event)
						//}
						
					}
					
					 this.lastAttackT = gAppCurT
					 
					 this.stateST  = gAppCurT 
					 
					 this.actState = act_attack
					 this.ball.setAct(act_attack)
					 
				}
						
						
						
			}
			else if(this.actState == act_attack){
				
				 if( gAppCurT >= this.stateST + 500){
					 
					  this.ball.setAct(act_idle)
					  this.actState = act_idle 
				 }
				
			}
            else if(this.actState == act_damage){
     
	 
                  //0.5s간 유지후 idle 
				  
				  if( gAppCurT >= this.stateST + 500){
					 
					  this.ball.setAct(act_idle)
					  this.actState = act_idle 
				  }


			 }						 

			
	}
	
	
	updateMovement(deltaT){
		
	 
	 let radius = this.ball.radius
	 
				
	 if(this.movePattern == move_h){

           let posx = this.ball.pos.x 
		   let posy = this.ball.pos.y					
					 					
	   	    posx += this.movePatternVelocityX*deltaT	
				
			let maxx = gClientW - radius
			let minx = 0.0 + radius
			
			if(posx >  maxx){
				
				gPrint('mon posx > maxx: ' + posx)

				   this.movePatternVelocityX = -1*this.movePatternVelocityX 
				   posx = maxx
				   
			}					
			else if (posx < minx){
				
				   this.movePatternVelocityX = -1*this.movePatternVelocityX 					
				   posx = minx
			}
			
			
			this.ball.pos.x = posx
			this.ball.pos.y = posy
			
								
		}	
		
		
		
	}
	
	
	
	
	update_mon2(){
				
	  let actState = this.actState			
	  
	  if(actState == act_idle){
		  		  
			
			 let fireT = this.lastAttackT + 5000 
			
		       if(this.ball.rscIdx == r_mon2_child){
				   
				  fireT =  this.lastAttackT + 10000
			   }				   
			
		          if( gAppCurT >= fireT && gIsPaused == false ){
						
						//attack cmd 				
						 let event = new CustomEvent("monster_fire_bullet", {detail:{id:this.ball_id} })
						 document.dispatchEvent(event)						 
				
						  this.stateST  = gAppCurT 					 
									
			 			  this.lastAttackT = gAppCurT
						  this.actState = act_attack
						  this.ball.setAct(act_attack)
						 
						  this.ball.iSpriteIdx = 1 
					
					}
					
			
		  
	  }
	  else if(actState == act_attack){
		  
		  
		 if( gAppCurT >= this.stateST + 500){
				 
				  this.ball.setAct(act_idle)
				  this.actState = act_idle 
			 }
	  
		  
	  }
	  else if( actState == act_damage){
				
					
			if( gAppCurT >= this.stateST + 500){
			 
				this.ball.setAct(act_idle)
				this.actState = act_idle 
				this.ball.iSpriteIdx= 0	
							
			 }
	
	  }
	
	}
	
	
	static getBulletDir(refX, refY, level){
		
  	   	  let dirV = {x: 0, y: 0}
		
			if(level == 0){							
			  
			  dirV.x = (gClientW*0.5 - refX)  
			  dirV.y = (gPlayerRefY -  refY)
			
			}
			else if(level == 1){
			
				dirV.x = getRandomVal(-5 , 5)
				dirV.y = 4
			
			}
			else if(level == 2){
				
				dirV.x = getRandomVal(-5 , 5)
				dirV.y = 6
				
			}
			
			
				let len = Math.sqrt(dirV.x*dirV.x + dirV.y*dirV.y)
				dirV.x = dirV.x/len 
				dirV.y = dirV.y/len
				
				return dirV
	}
	
	//===================
	update_mon3(){
	    				
         let actState = this.actState						
      
         if(actState == act_idle){

	            if(gAppCurT >= this.stateST + 5000 ){ 

                     this.ball.radius = pet_radius*1.8
		 
		 
					 let event = new CustomEvent("monster_fire_bullet", {detail:{id:this.ball_id} })
					 document.dispatchEvent(event)
					 
                     this.stateST = gAppCurT
					 this.actState = act_attack
				}


		 }			 
	    else if(actState == act_attack){
		  
		  
	           if( gAppCurT >= this.stateST + 500){
				 
				   this.ball.radius = pet_radius*1.4
				   this.ball.setAct(act_idle)
				   this.actState = act_idle 
			  }
	  		 			
		}
        else if(actState == act_damage){


        	if( gAppCurT >= this.stateST + 500){
			 
				this.ball.setAct(act_idle)
				this.actState = act_idle 
				this.ball.iSpriteIdx= 0	
							
			 }

		}			
		

	}

   //=======================
   //
    //======================
	update_defenseMon(){

	   let validFire = false 
	   
	   if(this.isReadyFire == false){

			if( gStageElapsT >= 2000){
			
				this.isReadyFire = true		
				validFire = true
				
			}
			else {
				
				return 
			}
			
	   }
	   
	   let maxFireCount = 3
	   
	   let minSpeed = 0.2 
	   let maxSpeed = 0.25
	   
	   
	       let refx = this.ball.pos.x 
		   let refy = this.ball.pos.y 
	   
			  
			 let interval = 30000
              
			 let level = this.ball.level
			  
			 if(level == 1){				
				//50초 
				interval = 25000	
				maxFireCount = 1
				
			 }
			 else if(level == 2){
				 
				 //20s
			     interval = 20000				

				 maxFireCount = 2
	
          	    minSpeed = 0.25 
				maxSpeed = 0.3
				 
			 }else if(level == 3){

                //15s
			     interval = 15000								 
				 maxFireCount = 2
                
 				minSpeed = 0.25
				maxSpeed = 0.35
				 
			 }
			 
			 
			 if(this.fireState == fireState_ready){
				 
				 
				 
				 
				 
			 }			 
			 if(this.fireState == fireState_firing){
				 
				   	console.log('fireState_firing')	
				 
				 if( this.fireCount < maxFireCount){
					 
						  if(gStageElapsT > this.lastFireT  + 1000){
						 
						    let posX, posY , range = rock_radius
						  
						    posX = refx + getRandomVal(-rock_radius, rock_radius)
						    posY = refy
						    addGameCmd('fire_monsterBullet', {x:posX, y:posY} ) 				   
								  
							this.fireCount++
							
							this.lastFireT = gStageElapsT

						  }						
			    }
				else {
					
					this.fireState = fireState_cooltime
				    this.lastAttackT = gStageElapsT 
					
				}
				 				 
				 
			 }
			 else if(this.fireState == fireState_cooltime) {
			 
			  
			   //	console.log('fireState_cooltime' + gStageElapsT + ', ' + interval)
														  
					if( gStageElapsT > this.lastAttackT + interval){		
				
				     	this.fireState = fireState_firing
						this.fireCount = 0
						this.lastFireT = gStageElapsT
					   	console.log('fireState_cooltime--->fireState_firing')	
					
					
					}	//
			
			 }

	    if(this.actState == act_damage){

          	if( gAppCurT >= this.stateST + 500){
			 
				this.ball.setAct(act_idle)
				this.actState = act_idle 
				this.ball.iSpriteIdx= 0	
							
			 }
	    }			
		
	   	   
	   
	   	if(this.fireCount >= maxFireCount){
			
			validFire = false 
			
		}
	   	
		let monB = this.ball 
		


       //----------------------------
		if(validFire == false){
			
			return 
		}


	 
	} //end of update_defenseMon()
	
	
	
} //end of class


function fireMonsterBullet(refx,refy){

          gPrint('fireMonsterBullet: ' + refx + ', ' + refy)

		  let diffx =  gDefenseBarX  - refx + getRandomVal(-rock_radius, rock_radius)
		  let diffy =  gPlayerRefY - refy 
		  
		  let len  = Math.sqrt(diffx*diffx + diffy*diffy)
		  let dirV = {x:0, y:0}
		  
		  dirV.x = diffx/len 
		  dirV.y = diffy/len 
		  

         let radius=	rock_radius*1.2
 	     let bullet = new ball(r_enemy_guard, radius)   

          bullet.id = getNewObjId()

	      bullet.setState(ballstate_move)
		  
		  
		  bullet.img = getImage(r_enemy_guard)			
		  
	      bullet.addSprFrame(0, 0, 128, 128)		  				
//	      bullet.addSprFrame(128, 0, 128, 128)		  
		//  bullet.useCustomSprIdx = true  
	  
		  //---------------------------------
		  //monster와 충돌하지 않도록
		  bullet.iSpriteIdx = 0 
		  bullet.addProp(ball_prop_attack_player)
		  
		  bullet.addProp(ball_prop_monsterBullet) //<-----
		  	  
		  bullet.addProp(ball_prop_not_draw)
		  bullet.addProp(ball_prop_not_gravity)
		  
		  bullet.addProp(ball_prop_topLayer)
	      //-----------	  
				  
		   bullet.rscIdx = r_enemy_guard
	
			
		   bullet.pos = {x: refx, y: refy}
		   
		   let speed =0.3
		   
		   bullet.velocity.x = dirV.x*speed
		   bullet.velocity.y = dirV.y*speed
		   
		  gBalls.push(bullet)

}	

function procMonsterBullet(bullet, deltaT){
	
  // gPrint('procMonsterBullet ')
   
    bullet.pos.x +=  bullet.velocity.x*deltaT             
	bullet.pos.y +=  bullet.velocity.y*deltaT   
   
	
	if(bullet.pos.y > gPlayerRefY + bullet.radius){
				
		bullet.isWaitForRemove = true 
		
		gPrint('monsterBullet outofBound -->isWaitForRemove=true')
	}
		
	
}


function addDefenseBall(refx, refy, speed,  isPlayer=true){
	
          gPrint('addDefenseBall ')						
						
  		 let radius=	rock_radius*0.8
	     let bullet = new ball(r_defense_ball, radius)   

          bullet.id = getNewObjId()


	      bullet.setState(ballstate_move)
		  
	  	  bullet.addSprFrame(0, 128, 128, 128)
		  bullet.addSprFrame(128, 128, 128, 128)
		  bullet.addSprFrame(165, 0, 91, 91)		  
		  bullet.useCustomSprIdx = true  
	  
		  //---------------------------------
		  //monster와 충돌하지 않도록
		  
		  if(isPlayer){
			
	 		  bullet.iSpriteIdx = 0 
              bullet.addProp(ball_prop_attack_enemy)		
			  
		  }
		  else {
	 	      bullet.iSpriteIdx = 1 
		      bullet.addProp(ball_prop_attack_player)
		  }
		 //---------------------------------	  
		  
		  bullet.addProp(ball_prop_not_draw)
		  bullet.addProp(ball_prop_not_gravity)
	      //-----------	  
				  
		   bullet.rscIdx = r_defense_ball
		   bullet.img = getImage(r_defense_ball)     
			 

			bullet.pos = {x: refx, y: refy}
		   

			gBalls.push(bullet)

			
           if(speed == 0.0){
			   
				bullet.angleSpeed = 0
				
				bullet.velocity.x = 0
				bullet.velocity.y = 0 

               return 	bullet 		   
  		    }

		   					
			let angle
			
			if(angle < 0){
				
				angle += 360
			}
			
			
			let dirV
		
			 if(isPlayer){
	   
			  angle = getRandomVal(270-50, 270+50)
			  dirV = rotateVec(0.0, -1.0, angle)
			  
	    	}
  		    else {

			   angle = getRandomVal(270-50, 270+50)
			   dirV = rotateVec(0.0,  1.0, angle)
			  
		    }	
			   
		   
		    bullet.velocity.x = dirV.x*speed
			bullet.velocity.y = dirV.y*speed 
		   
			 
		   gPrint( ' --->fire defenseBall(' + bullet.id + ')')
	
	       return bullet
	
}






class itemAI{
	
	constructor(ball){
      
	  this.ball = ball 

	}
	
	init(){
		
    gPrint('itemAI.init()')		
		
	}
	
	update(){
		
	}
	
}


//==========================
class rockEatAI{
	
	
	constructor(ball){
      
	  this.ball = ball 
	  this.eatST = 0
	  
	  this.isEat = false 
	  
	  this.targetId = 0
	  
	}
	
	beginEat(targetId){
		
		this.isEat = true 
	    this.eatST = gAppCurT 
		
		this.targetId = targetId         
      //   this.ball.addProp(ball_prop_not_collision_ball)		
		
	}
	
	releasePetBall(){
		
	if(this.targetId == 0 ){
		
		return 
	}
				
	 let petBall = getBall(this.targetId)
				 
	   if(petBall == null){
		   
		    return 
	   }
	   
	   petBall.setState(ballstate_fallingDown)	   
	}
	
	
	update(){
		
	   if(this.isEat){

			 if(gAppCurT >= this.eatST + 500){
				 
				 //링크된 petBall을 방향을 틀어서 날려보냄 
				 
				 let petBall = getBall(this.targetId)
				 
				 if(petBall == null){
					 
					 gPrint('petBall ' + this.targetId + ' ==null')
					 return 
				 }
								 
				 removeDistJointAB(this.ball.id, petBall.id)
				// petBall.addProp(ball_prop_not_collision_ball)
				 petBall.setState(ballstate_move)
				 

                 let randX = getRandomVal(-0.3,  0.3)			
                 let randY = getRandomVal(-0.3, -0.5)			
			
				 petBall.setVelocity(randX, randY)				 
				 
				 this.targetId = 0		        				
				 this.isEat = false 			 
			 }

	   }		   
		
	}
	
	
			
}

//------------------------

class groupEntity{
	
	constructor(){
		
		this.balls = [] 		
		
		this.moveKind = move_none 
		
		this.minx = 500 
		this.maxx = 0
		this.width = this.maxx - this.minx 
		this.ball_radius = 30 
		
		this.vel =  {x:0, y:0}
		
		//LeftTop
		this.pos = {x:0, y:0}
		
	}
	
	//
	//
	addEntity(ball){
			
		if(this.balls.length == 0){
			
			//첫번째 라면 
			this.pos.x = ball.pos.x 
			this.pos.y = ball.pos.y 	
			
			this.ball_radius = Math.floor(ball.radius)
			
		}else {
			
		}
					
        this.balls.push(ball)		
		
	}

   //==========	
	delEntity(id){
		
		let b		
		for(let idx=0;  idx < this.balls.length; idx++){
			 
			  b = this.balls[idx]
			  
			  if(b == null){
				  
				  continue 
			  }
			  
			  if(b.id == id){
				  
		  	 	  gPrint('group delEntity: ' + id)
			      //this.balls.splice(idx, 1)
				  //idx--
				  this.balls[idx] = null
				  break;
			  }
		}
		
		this.updateBound()
		
	}
	
	
	updateBound(){
		let b, tmpx		
		for(let i=0;  i < this.balls.length; i++){
			 
			  b = this.balls[i]
			  if(b==null){
				  
				 continue   
 			   }
			  
			  tmpx = b.pos.x - b.radius
			  
			  if(tmpx < this.minx){
				  this.minx = tmpx 
			  }
			  
			  tmpx = b.pos.x + b.radius 		  
			  if(tmpx > this.maxx){
				  
				  this.maxx = tmpx 
			  }				
		}
		
		this.width = this.maxx - this.minx 
		
		gPrint('group updateBound' + this.minx + ',' + this.maxx + ',w: ' + this.width)
				
		
	} //updateBound(0
	
	update(deltaT){
				
		if(this.moveKind == move_h){
			
			this.pos.x += this.vel.x*deltaT 
			
			this.minx = this.pos.x 
			this.maxx = this.minx + this.width
			
			if(this.maxx >= gClientW){
				
				this.vel.x = -1*this.vel.x 		
			    this.pos.x = gClientW - this.width
				
			//	gPrint('group maxx: ' + this.maxx)
				
			}
			else if(this.minx <= 0  ){
				
				//<--->
				 this.vel.x = -1*this.vel.x 				
				 this.posx = 0
			}
			
		//	gPrint('group pos: ' +  this.pos.x)
		    let b
			let posx
		    for(let i=0; i < this.balls.length; i++){
				
             	  b = this.balls[i]		  
                 if(b==null) { 
				    continue				  
				 }
				 
		          posx = (this.pos.x + b.radius) + b.radius*2*i	
				  b.pos.x = posx 
                  b.anchor.x = posx 				  
			}
												
		}
		
	}	
	
	
}

//==========================
function proc_enemyGurad(bullet, deltaT){
	
//	   gPrint('proc_enemyGurad')
	 
	   if(bullet.state == ballstate_move){

          if(bullet.hasProp(ball_prop_not_gravity) == false ){
			  
			  bullet.velocity.y += (worldGravity)*deltaT				 			  
		  }	

	
		   	let minX = 0
	        let maxX = gClientW
						
			
			 bullet.pos.x +=  bullet.velocity.x*deltaT             
			 bullet.pos.y +=  bullet.velocity.y*deltaT
			 
			 
			 if( bullet.hasProp(ball_prop_not_collision_wall) ){
				 
				 
				 	if(bullet.pos.x <= minX){
						
						bullet.isWaitForRemove = true 
					} 
					else if(bullet.pos.x >= maxX){
						
						bullet.isWaitForRemove = true 
						
					}
				 
				 
				 
			 }
			 else {
			 
			 
				if(bullet.pos.x <= minX){
									 
						 bullet.pos.x = minX
						
						 bullet.velocity.x = -1.2*bullet.velocity.x
						 
						if(gAppState == appState_play){			
						     
							 //playSoundEffect(sound_hit_01)							 
						     bullet.setState(ballstate_anchored)
						}
							 
				 }
				 else if(bullet.pos.x >= maxX){

						bullet.pos.x = maxX
						
						bullet.velocity.x = -1.2*bullet.velocity.x				
																					
						if(gAppState == appState_play){															

							//playSoundEffect(sound_hit_01)
							bullet.setState(ballstate_anchored)
					   }
							 
				 }
			 
			 }
			 
			 
			 
			if(gAppState == appState_play){	 
			
				if(bullet.pos.y >= bullet.moveMaxY ){
					
					 bullet.setState(ballstate_anchored)					  
					
					return 
				}
		   }
				 
			
			 if(bullet.pos.y < bullet.radius || bullet.pos.y > gClientH+bullet.radius ){ 
			 //윗쪽 wall에 충돌하거나 ground밑으로 간경우 경우 
				 
				  bullet.setState(ballstate_fallingDown)					  
				 
				  return						
			  }
			  
			
			 	   
	   }
		
		
	  if(bullet.state == ballstate_move_toDst){
		  
		    let distX  = (bullet.userPos.x - bullet.pos.x)  
			let distY  = (bullet.userPos.y - bullet.pos.y)

            let deltaX = distX/20  
			let deltaY = distY/20 
			
			bullet.pos.x +=deltaX 
			bullet.pos.y +=deltaY
		
           if(distX < 2  && distY < 2){
			   			   
			   bullet.state = ballstate_move_pattern
			   bullet.movePatternIdx = move_circle						   
		   }			   
		   
	  }		  
	  else  if(bullet.state == ballstate_move_pattern){
		  
		
		 if(bullet.movePatternIdx == move_pattern_circle){
			 
			 proc_movePattern_circle(bullet, 20)
			 
		 }
		 else if(bullet.movePatternIdx == move_pattern_circle2){
			 			 
			   proc_movePattern_circle2(bullet, 20)			 
			 
		 }
		 else{
			 
 			  proc_movePattern_byDstPos(bullet, 20)
			 			 
		 }
		
	 }
	   		
}


//paddle과 충돌
function proc_defenseBall_collision_generic(defenseB){
	
    let width = 100
	let height = 50
	
	let radius = defenseB.radius
	

    let x = defenseB.pos.x 
	let y = defenseB.pos.y

    let minX = gDefenseBarX - width/2
    let maxX = gDefenseBarX + width/2



    let isInPaddle = false
    let isCollisionY = false
	

    if(x >= minX && x <=maxX) {

       isInPaddle = true 
     }
	 else {

       isInPaddle = false  		 
	 }

    defenseB.pos.x = x
	
	let testRefY = y + defenseB.radius 
	
	
	//====================
	
    //colli defenseBar
    if(defenseB.pos.y <  gPlayerRefY && testRefY >=gPlayerRefY  ){

           isCollisionY = true
		   
		   if(isInPaddle){
			   
 		       defenseB.velocity.y = -1.0 * defenseB.velocity.y
			   defenseB.pos.y = gPlayerRefY - radius
			   			   
						   
			  let diffX 			   
						   
			  let speed = getVecLength(defenseB.velocity)			   
						   
              						   
	          let refVel =  {x:0, y: -1.0} //defenseB.velocity
			  
			  let angle = 0 //degree
			  
			  
			 let hWidth  = paddleW/2
			 
			  
			  //<---  50 ---> |<--- 50 ----> 
			  //        |     10 |10  20  20
			  if(defenseB.pos.x < gDefenseBarX){
				   
				   //좌측 
				   
                    diffX = gDefenseBarX - defenseB.pos.x 

                    if(diffX > (hWidth*2/3)  ){
						
				       angle = -30 						
					}
					else if(diffX >(hWidth*1/3) ){
						
					   angle = -45 
					}
					else {

					   angle = -45 

					}
				   
					 playSoundNote(sound_note_do)	
				  
			  }
			  else if(defenseB.pos.x > gDefenseBarX){
				   
				    //우측
				   
                    diffX = defenseB.pos.x - gDefenseBarX

                    if(diffX > 30){
						
				       angle = 30 						
					}					
					else if( diffX > 10){
						
					   angle = 45 
					}
					
	 			    playSoundNote(sound_note_re)	

				  
			  }
			  else {
				  
				      playSoundNote(sound_note_mi)				  
			  }
			  


              //refVel--->unitV
			  let vel2 = rotateVec2(refVel , angle) 			  
			  defenseB.velocity.x = vel2.x*speed
			  defenseB.velocity.y = vel2.y*speed

             //  console.log('defensB collide  bar diffX: ' + gDefenseBarDiffX)				
			  
                //이후 petBall처럼 처리
		        defenseB.removeProp(ball_prop_attack_player)
                defenseB.addProp(ball_prop_attack_enemy)  	
				
				defenseB.addProp(ball_prop_not_gravity)
				
				defenseB.iSpriteIdx = 0
				
	            return true 

						   
		   }
		   else {
			   
			
			
		   }
		   
      
    }
    else {


    }



   if(defenseB.pos.y > gPlayerRefY + 50){	   
   
	   console.log('defenseB is under paddle')
	   defenseB.isWaitForRemove = true	   
	   
	  let  remainDefensB =  getFirstDefensBall()
	  
	  if(remainDefensB == null){

	        //stage faile
	        addGameCmd('stage_fail', null)		  
	   }
	  	   
	   return true 
   }
		
   return false 	
}


function proc_defenseBall_collideWith_ball(defenseB, peerB, col_info){
	
	gPrint('proc_defenseBall_collideWith_ball')
	
	if(defenseB.hasProp(ball_prop_attack_enemy)==false ) {
		
		return
	}
		
		
		if(peerB.rscIdx == r_enemy_guard){
			
			proc_petBall_collide_enemyGuard(defenseB, peerB)
			
		}
		else if( isItem(peerB) ){
			
			//bomb과 충돌시 처리해야함 
            //나머지 아이템은 paddle과 충돌처리 			
			//충돌후 defenseBall remove하지 않기 위해 false 세팅
			   defenseB.collideWith_item(peerB, false)
						
		}		
		else if(peerB.rscIdx == r_rock_float_anchor ||  peerB.rscIdx == r_rock_reflect 
		        || peerB.rscIdx == r_rock_reflect2 
		        || peerB.rscIdx == r_rock_reflect3
		        || peerB.rscIdx == r_rock_reflect4 
		        || peerB.rscIdx == r_rock_reflect_invincible
				|| peerB.rscIdx == r_rock_breakable){
			
              //false(--->isRemove, 충돌후에도 ball 유지)
			   defenseB.proc_collideWith_reflectRock(peerB, col_info, false)
		
		}
		else if ( isPetBall(peerB) ) {
              
              //아이템처럼 paddle과 충돌해야 획득가능		
               peerB.iSpriteIdx = 1			  
			   peerB.setState(ballstate_fallingDown2)
			   
			   //
			   
			    peerB.isFocus = true 
			    peerB.radius = rock_radius*1.2
			    peerB.userEventT = gStageElapsT
	   
			   
			   //--------
			   playSoundEffect(sound_cat_01)			   
			   
			   let respV_info2 =  get_ball_responseV_d1(defenseB, peerB)
			   //unitVector이므로 speed를 반영해줘야 합니다.
			   
			   let respV = respV_info2.respV 
			   let rePos = respV_info2.rePos
				
			   let speed = getVecLength(defenseB.velocity)
			   
			   				
				//반사벡터 적용하기			
			
				defenseB.pos.x = 	rePos.x
				defenseB.pos.y = 	rePos.y

				defenseB.velocity.x = respV.x*speed
				defenseB.velocity.y = respV.y*speed
				
								
				//점수 반영하기 				
				gUserScore += 2								
				let spr = addScoreSpr(peerB.pos.x, peerB.pos.y , 2 )
			    spr.colorStr = '#FD9301'		
		
			 
			 if(peerB.rscIdx == r_cat_red){
				 				 
				playSoundNote(sound_note_si)
             
			    addDebrisEffect(peerB.pos.x, peerB.pos.y, debris_enemyBullet)
				 
			 }
			 else {
						
				playSoundNote(sound_note_do2)

			 }			
              
		}			
							 			
}


//defenseB, itemB, monsterBullet 
function proc_paddle_collideWith_ball(ball){
	
	
	let refY = gPlayerRefY
		
    let width = paddleW
	let height = 50
	

   // ball.pos.x  ball.pos.y 
      
   let minX = gDefenseBarX - width/2  
   let maxX = gDefenseBarX + width/2 
   
   let lineS = {x: minX, y: refY}
   let lineE = {x: maxX, y: refY}
   
   
   let diffX = lineS.x - ball.pos.x 
   let diffY = lineS.y - ball.pos.y
   let normalV = {x:0, y: 1.0}
   

      
   if(ball.pos.y > refY + ball.radius){

	   
	   if(ball.rscIdx == r_defense_ball){
	   
			  console.log('defenseB is under paddle')
			  ball.isWaitForRemove = true	   
			   
			  let  remainDefenseB =  getFirstDefenseBall()
			  
			  if(remainDefenseB == null){
					//stage faile
					addGameCmd('stage_fail', null)		  
			   }
	   
	   }
	   else if(isItem(ball)){
		   
        	  console.log('item is under paddle ' + ball.pos.y)
			  ball.isWaitForRemove = true	   
		   
	   }	   
	   else if(isPetBall(ball) ){
		   
		    //petBall 놓친경우 
			
		   	  console.log('petBall is under paddle')
			  ball.isWaitForRemove = true	   
		  		   	   
	   }
	   
	  	    
       return false 	   
    }
	
	//targetBalldl 위쪽에 있는 경우 
	
  if(ball.pos.x < minX-ball.radius){
	   
	   return false 
   }

   if(ball.pos.x > maxX+ball.radius){
	   
	   return false 
   }
	
    //let len = Math.sqrt(diffX*diffX + diffY*diffY)   
   let dot = diffX*normalV.x + diffY*normalV.y  
   
 //  gPrint(' paddle collideWith ball' + 'dot ' + dot )
   
   //충돌발생 
   if(dot <= ball.radius){
	   
	 //   gPrint('----paddle collideWith ball----')	
	   
	   if(ball.rscIdx == r_defense_ball){
		   
		   		 
		   //위치 보정 		 
	       ball.pos.y = gPlayerRefY - ball.radius
				 
		   post_paddle_collide_defenseBall(ball)
	   }
	   else if(isItem(ball)){		   
		   
		   let refB = getFirstDefenseBall()

		   if(refB != null){
		   
		   		  post_paddle_collide_item(ball)
		   }

	   }else if( isPetBall(ball) ){
		   
		  post_paddle_collide_petBall( ball )
		   
	   } //monsterBullet과 paddle
	   else if(ball.hasProp(ball_prop_monsterBullet) ){
		   		   
		   let xp = gDefenseBarX
           let yp = gPlayerRefY		   
		   
		   	let spr =addEffectSpr(xp, yp, 1, 150, 1000)
			spr.motion.angleSpeed = 3
			spr.sizeSpeedLevel = 1
			
			beginEarthQuake()
			
		   gPrint('paddle col enemybullet')
		   
		   playSoundEffect(sound_bomb)
		   
		    gAppSubstate =   playSubstate_stageEnd_pending
		   	//stage faile
	 	    addGameCmd('stage_fail', null, 1000)		  
		   
	   }
	   
	   //충돌
	   return true 
   }


    return false 
	
}


function post_paddle_collide_petBall(petB){
	
	gPrint('post_paddle_collide_petBall')
	
	gNumSavePet += 1
		
    gUserScore += 50

    let spr =  addScoreSpr(petB.pos.x, petB.pos.y, 50)
    spr.colorStr = '#FD9301'	
	
  //------------------------------------
   if(_savedPetArray.indexOf(petB.rscIdx) == -1){
	   
	    _savedPetArray.push(petB.rscIdx)	   			
		//저장하기 	
	   let dataStr = JSON.stringify(_savedPetArray)	
	   window.localStorage.setItem('_savedPetArray', dataStr)
	   gPrint(dataStr)
	}
  //-----------------------------------
	
	
	petB.isWaitForRemove = true 	

   gSavePetRscIdx_array.push(petB.rscIdx)	
	
   if(petB.effectSpr != null){
	   
	   let effSpr = petB.effectSpr 
	   effSpr.isWaitForRemove = true 
	   
	   petB.effectSpr = null 
   }
   
   //save목록에 등록

}


function post_paddle_collide_item(itemB){

	procItem(itemB)
	
		if(itemB.rscIdx != r_item_bomb){
			
			playSoundEffect(sound_good)			
		}
		
		if(itemB.rscIdx == r_item_photo){
			
			
	       addGameCmd('get_prizephoto' , null)
			
		}
		else  if(itemB.rscIdx == r_item_heart){

              

		}else if(itemB.rscIdx == r_item_slow){


		}else if(itemB.rscIdx == r_item_double){

  
		}			
		
		itemB.isWaitForRemove = true 

}



//이미 충돌상태 
function post_paddle_collide_defenseBall(defenseB){
	
	          let diffX
	
			  let speed = getVecLength(defenseB.velocity)			

             if(speed > gMaxSpeed){
				 
                speed = gMaxSpeed 
			 }				 
              						   
	          let refVel =  {x:0, y: -1.0} //defenseB.velocity
			  
			  let angle = 0 //degree
			  
			  let hPaddleW = paddleW/2
			  
			  //<---  50 ---> |<--- 50 ----> 
			  //        |     10 |10  20  20
			  if(defenseB.pos.x < gDefenseBarX){
				   
                    diffX = gDefenseBarX - defenseB.pos.x 
					
					let ratio = diffX/hPaddleW
					
					angle = -10 -ratio*50
							   
					 playSoundNote(sound_note_do)	
				  
			  }
			  else if(defenseB.pos.x > gDefenseBarX){
				  
                    diffX = defenseB.pos.x - gDefenseBarX
					let ratio = diffX/hPaddleW
					
					angle = 10 + ratio*50
			
	 			    playSoundNote(sound_note_re)	
				  
			  }
			  
			  /*
			  else {
				  
				  //    playSoundNote(sound_note_mi)				  
			  }
			  */

              
              //refVel--->unitV
			  let vel2 = rotateVec2(refVel , angle) 			  
			  defenseB.velocity.x = vel2.x*speed
			  defenseB.velocity.y = vel2.y*speed

             //  console.log('defensB collide  bar diffX: ' + gDefenseBarDiffX)				
			  
                //이후 petBall처럼 처리
		        defenseB.removeProp(ball_prop_attack_player)
                defenseB.addProp(ball_prop_attack_enemy)  	
				
				defenseB.addProp(ball_prop_not_gravity)
				
				
				if( defenseB.hasProp(ball_prop_invincible) == false ){
					
				   defenseB.iSpriteIdx = 0
				}
				
}



function   getVelocity_attackToPaddle(iSpeed){

	 	    let monFaceV = {x:0.0, y: 1.0}											
		
            let angle = getRandomVal(-45 ,  +45)

			let angleR =angle*(Math.PI/180)
					
		    let resV = {x:0, y:0}
		    resV.x = Math.cos(angleR)*monFaceV.x - Math.sin(angleR)*monFaceV.y 
		    resV.y = Math.sin(angleR)*monFaceV.x + Math.cos(angleR)*monFaceV.y 
			
			let newSpeed	
										 
			 if(gNumRetry >= 2){
				 
				 newSpeed = iSpeed*0.95 
			 }
			 else {
				 
				 newSpeed = iSpeed*1.1
			 }

             resV.x = resV.x*newSpeed 			
             resV.y =resV.y*newSpeed 			

             return resV 
	   
   }
   
//r2 총알로 데미지가능 
function post_paddleBullet_collideWith_ball(bullet, target){
	
	
	 	  bullet.isWaitForRemove = true 
		  //총알이 충돌후 통과하면 안 됨 
		 
		 //ball로는 파괴되지 않는 것들 
	      if( target.rscIdx == r_rock_reflect_invincible){
			 //invincible
			 
			  target.isHit = true 
			  target.hitEventT = gAppCurT

			  target.iSpriteIdx = 1 
			  playSoundNote(sound_note_hit)
			  			  
			 return 
		 }
		 
		 
		 	 let refx = target.pos.x 
			 let refy = target.pos.y
			 
             target.hp -= 2 			 
	 
			 //-------------------------------------------
 	         gUserScore  += 2						 
		     let spr = addScoreSpr(target.pos.x, target.pos.y, 2)		
			 
			 if( isMonster(target) ) {
				
				 spr.colorStr = '#FA0000'			 
			 }			 			 
			 else if(target.rscIdx == r_rock_reflect2 || target.rscIdx == r_rock_reflect3){

			       spr.colorStr = '#FA0000'				 
			 }
			 else if(target.rscIdx == r_rock_breakable){
			 
			       spr.colorStr = '#c0c0c0'				 
			 
			 }
			else if(target.rscIdx == r_rock_reflect4){

                 spr.colorStr = '#A3F914'		
		  	 }	
			 else {
			 			 
			     spr.colorStr = '#FD9301'
			 }
			 //------------------------------------------
		 			 		 
           if(isMonster(target)){
			   		     
       		       let monB = target
							   
				   if(monB.hp <= 0){

					 post_monsterDead(target)
				   }
				   else {
					   
                         monB.addProp(ball_prop_restore_toAnchor)
						 
                         monB.pos.x += 0
						 monB.pos.y += rock_radius*0.2
						
						 monB.restoreDist.x = monB.anchor.x - monB.pos.x 
						 monB.restoreDist.y = monB.anchor.y - monB.pos.y 
						 monB.restoreUpdateCount = 0 
					   
				   }
				 
				 	  addMonsterDamageTextSpr(refx, refy, 2)	  
					 //0.3초간 짧게 빨간 이펙트 한 번만 
					  addEffectSpr(refx, refy, 1, 150, 300)
				 
				 return 
		   }			   

     
		 if(target.hp <= 0){
			 
			 if(target.rscIdx == r_rock_reflect){
				 //hp:6
				 
				 addDebrisEffect(target.pos.x, target.pos.y, debris_reflect)
							 
			 }
			 else if(target.rscIdx == r_rock_reflect2 || target.rscIdx == r_rock_reflect3){
				 
				 addDebrisEffect(refx, refy, debris_reflect3)
							 
			 }			 
			 else if(target.rscIdx == r_rock_breakable){
				
				 addDebrisEffect(target.pos.x, target.pos.y, debris_rock)
				
			 }			 
			 else {
			 
			 			 			
			 }
			 
			  target.isWaitForRemove = true 
			 
              playSoundEffect(sound_broken)			
			
			
		 }
		 else {
			 
			  if(target.rscIdx == r_rock_breakable){
			 
			          target.iSpriteIdx +=1
					  
					  if(target.iSpriteIdx >= 2){
						  
						 target.iSpriteIdx = 2 
					  }
					  
		        }				
				else if (target.rscIdx == r_rock_reflect || target.rscIdx == r_rock_reflect2 
				         || target.rscIdx == r_rock_reflect3){
				
				       target.isHit = true 
					   target.hitEventT = gAppCurT

					   target.iSpriteIdx = 1 
		       }
				
		 	    playSoundNote(sound_note_hit)
			 
		 }
		 
		 
		// gPrint('target.rscIdx: ' + target.rscIdx)

}	


 function post_monsterDead(monB) {

            if(monB.actState == act_dead){
				
				console.log('monB: alreadDead')
			}
			
			let refx = monB.pos.x 
			let refy = monB.pos.y 
			
			
				
			gNumOfKillMonster++	
           			
	        console.log('post_monsterDead numOfKillMonster '  + gNumOfKillMonster)
			
			monB.setAct(act_dead)	
            monB.setState(ballstate_small_toDeath)			
			
			if(monB.effectSpr != null){
				
				let effSpr = monB.effectSpr
				effSpr.isWaitForRemove = true 
				monB.effectSpr = null 
			}
 

           if(monB.post_rscIdx == r_wake_monster){
			   	
			   addGameCmd('post_rscIdx',  {x:refx, y: refy, rscIdx: r_wake_monster }   ) 
					   
		   }
		   else {            			
					let  first = getFirstMonster()
					//마지막 monster인 경우 
					if(first == null){

					  //마지막 monster일 경우에  photo item 
					  // addGameCmd('post_rscIdx',  {x:refx, y: refy, rscIdx: r_item_photo }   ) 				
                       stopDefenseBalls() 
					   
 				    } 
		    }
			
		
 }


let pattern_u_dst_pos_array = [] 
let pattern_v_dst_pos_array = [] 

//let pattern_u1_dst_pos_array = [] 

//let pattern_s_dst_pos_array = [] 
let pattern_tri_1_dst_pos_array = [] 
let pattern_tri_2_dst_pos_array = [] 

//horizon
let pattern_line_dst_pos_array = []
//vertical 
let pattern_line_v_dst_pos_array = []


let pattern_wave_h_dst_pos_array = []
let pattern_wave_v_dst_pos_array = []

let pattern_rect_dst_pos_array = [] 


function initMovePatternArray(){
	
	//   [6](1,1)           [0](6,1)
	//     [5]           [1]
	//        [4] [3] [2] 	
	//slotIdx
	/*
    pattern_u_dst_pos_array.push( {x:6, y:1} )
    pattern_u_dst_pos_array.push( {x:6, y:3} )
    pattern_u_dst_pos_array.push( {x:5.0, y:5} )	
    pattern_u_dst_pos_array.push( {x:4.5, y:6} )	
	//----
    pattern_u_dst_pos_array.push( {x:3.5, y:8} )
	//----
    pattern_u_dst_pos_array.push( {x:2.5, y:6} )	
    pattern_u_dst_pos_array.push( {x:2.0, y:5} )	
    pattern_u_dst_pos_array.push( {x:1.0, y:3} )
    pattern_u_dst_pos_array.push( {x:1.0, y:1} )
		
*/

    pattern_u_dst_pos_array.push( {x:5.0, y:1} )
    pattern_u_dst_pos_array.push( {x:5.0, y:3}  )
    pattern_u_dst_pos_array.push( {x:5.0, y:5} )	
    pattern_u_dst_pos_array.push( {x:4.5, y:6} )	
	//----
    pattern_u_dst_pos_array.push( {x:3.5, y:8} )
	//----
    pattern_u_dst_pos_array.push( {x:2.5, y:6} )	
    pattern_u_dst_pos_array.push( {x:2.0, y:5} )	
    pattern_u_dst_pos_array.push( {x:2.0, y:3} )
    pattern_u_dst_pos_array.push( {x:2.0, y:1} )
	
	//==================
	//==================

    pattern_v_dst_pos_array.push( {x:7.0, y:-1.0} )	
    pattern_v_dst_pos_array.push( {x:6.0, y:0.0} )
    pattern_v_dst_pos_array.push( {x:5.0, y:2.0}  )
    pattern_v_dst_pos_array.push( {x:4.0, y:4.0} )	
    pattern_v_dst_pos_array.push( {x:3.5, y:6.0} )	
	//----
    pattern_v_dst_pos_array.push( {x:3.0, y:4.0} )	
    pattern_v_dst_pos_array.push( {x:2.0, y:2.0} )
    pattern_v_dst_pos_array.push( {x:1.0, y:0.0} )
    pattern_v_dst_pos_array.push( {x:0.0, y:-1.0} )
			
   
   //                [0]
   //          [1]
   //    [2]
   // [3]
   //    +
   //       + 
   //          + 
   //              +
  
      
	pattern_tri_1_dst_pos_array.push( {x:6, y: 1.0} )
	pattern_tri_1_dst_pos_array.push( {x:4, y: 2.0} )
	pattern_tri_1_dst_pos_array.push( {x:2, y: 3.0} )
	
	pattern_tri_1_dst_pos_array.push( {x:0, y: 4.0} )	

	pattern_tri_1_dst_pos_array.push( {x:2, y: 6.0} )
    pattern_tri_1_dst_pos_array.push( {x:4, y: 7.0} )
	pattern_tri_1_dst_pos_array.push( {x:6, y: 9.0} )

   //  [0]   
   //         [1]   
   //                [6]
   //            [7]
   //      [8] 
   // [9]

    pattern_tri_2_dst_pos_array.push( {x:0, y: 1.0} )
	pattern_tri_2_dst_pos_array.push( {x:2, y: 2.0} )
	pattern_tri_2_dst_pos_array.push( {x:4, y: 3.0} )
	
	pattern_tri_2_dst_pos_array.push( {x:6, y: 4.0} )	

	pattern_tri_2_dst_pos_array.push( {x:4, y: 6.0} )
    pattern_tri_2_dst_pos_array.push( {x:2, y: 7.0} )
	pattern_tri_2_dst_pos_array.push( {x:0, y: 8.0} )
	
	
	/*
	pattern_s_dst_pos_array.push( {x:4, y:5.5} )
	pattern_s_dst_pos_array.push( {x:2, y:6.0} )
	pattern_s_dst_pos_array.push( {x:1, y:6.5} )	
	*/
	
	/*
	pattern_s_dst_pos_array.push( {x:2, y:6.0} )
	pattern_s_dst_pos_array.push( {x:4, y:5.5} )
	pattern_s_dst_pos_array.push( {x:6, y:5.0} )	
	
	pattern_s_dst_pos_array.push( {x:4, y:4.5} )
	pattern_s_dst_pos_array.push( {x:2, y:4.0} )
	pattern_s_dst_pos_array.push( {x:1, y:3.5} )	

	pattern_s_dst_pos_array.push( {x:2, y:3.0} )
    pattern_s_dst_pos_array.push( {x:4, y:2.5} )
*/

	
/*
	pattern_s_dst_pos_array.push( {x:1, y:6.0} )		
	pattern_s_dst_pos_array.push( {x:2, y:6.0} )
    pattern_s_dst_pos_array.push( {x:4, y:6.0} )
	pattern_s_dst_pos_array.push( {x:6, y:6.0} )
*/		
	
	//===============
	//line_horizon
	//----------------------
	//patternRefPos 기준 상대값을 사용 
	//y: slotIdx 상대좌표
	pattern_line_dst_pos_array.push({x:0, y:0})
    pattern_line_dst_pos_array.push({x:1, y:0})
	pattern_line_dst_pos_array.push({x:2, y:0.5})
    pattern_line_dst_pos_array.push({x:3, y:0})
	pattern_line_dst_pos_array.push({x:4, y:0})
    pattern_line_dst_pos_array.push({x:5, y:0.5})
		
	pattern_line_dst_pos_array.push({x:6, y:0})	
	pattern_line_dst_pos_array.push({x:8, y:0.5})

	pattern_line_dst_pos_array.push({x:9, y:0.5})

	pattern_line_dst_pos_array.push({x:10, y:0})


	pattern_line_dst_pos_array.push({x:4,  y:0} )
	pattern_line_dst_pos_array.push({x:-2, y:0})
	
	//--------------------------
	//line_vertical 
	//--------------------------
	//
	pattern_line_v_dst_pos_array.push({x:0, y:0.0})
    pattern_line_v_dst_pos_array.push({x:0, y:2.0})
	pattern_line_v_dst_pos_array.push({x:0, y:4.0})
    pattern_line_v_dst_pos_array.push({x:0, y:6.0})
	
//	pattern_line_v_dst_pos_array.push({x:0, y:7.0})

	pattern_line_v_dst_pos_array.push({x:0, y:8.0})

	//pattern_line_v_dst_pos_array.push({x:0, y:9.0})

	pattern_line_v_dst_pos_array.push({x:0, y:10.0})

    pattern_line_v_dst_pos_array.push({x:0.5, y:8.0})

    pattern_line_v_dst_pos_array.push({x:0.5, y:6.0})
    pattern_line_v_dst_pos_array.push({x:0.5, y:4.0})
    pattern_line_v_dst_pos_array.push({x:0.5, y:2.0})

    pattern_line_v_dst_pos_array.push({x:0.5, y:0.0})



   //==================
	pattern_wave_h_dst_pos_array.push({x: 0.0,  y: 0.0})
    pattern_wave_h_dst_pos_array.push({x: 1.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 2.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 3.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 4.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 5.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 6.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 7.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 8.0,  y: 2.0})
	
	pattern_wave_h_dst_pos_array.push({x: 7.0,  y: 0.0})	
    pattern_wave_h_dst_pos_array.push({x: 6.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 5.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 4.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 3.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 2.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: 1.0,  y: 0.0})
	pattern_wave_h_dst_pos_array.push({x: 0.0,  y: 2.0})
	pattern_wave_h_dst_pos_array.push({x: -1.0,  y: 1.0})
	
	

   //=================
   //==================
	pattern_wave_v_dst_pos_array.push({x:  1.0,   y: 0.0})
	pattern_wave_v_dst_pos_array.push({x: -1.0,   y: 1.0})
	pattern_wave_v_dst_pos_array.push({x: 1.0,   y: 2.0})
	pattern_wave_v_dst_pos_array.push({x: -1.0,   y: 3.0})
	pattern_wave_v_dst_pos_array.push({x: 1.0,   y: 4.0})	
	pattern_wave_v_dst_pos_array.push({x: -1.0,   y: 5.0})
	pattern_wave_v_dst_pos_array.push({x: 1.0,   y: 6.0})
	pattern_wave_v_dst_pos_array.push({x: -1.0,   y: 7.0})
	
	pattern_wave_v_dst_pos_array.push({x: 2.0,   y: 6.0})
	pattern_wave_v_dst_pos_array.push({x: 0.0,   y: 5.0})
	pattern_wave_v_dst_pos_array.push({x: 2.0,   y: 4.0})
	pattern_wave_v_dst_pos_array.push({x: 0.0,   y: 3.0})
	pattern_wave_v_dst_pos_array.push({x: 2.0,   y: 2.0})
	pattern_wave_v_dst_pos_array.push({x: 0.0,   y: 1.0})
	pattern_wave_v_dst_pos_array.push({x: 2.0,   y: 0.0})


//===============

   //(기준점 0,0)
    pattern_rect_dst_pos_array.push( {x:1, y: 1}  )
    pattern_rect_dst_pos_array.push( {x:6, y: 1} )
    pattern_rect_dst_pos_array.push( {x:6, y: 7} )
    pattern_rect_dst_pos_array.push( {x:1, y: 7} )
    pattern_rect_dst_pos_array.push( {x:1, y: 1} )
			
}



//maxIdx --> [0]
//바로 warp
function proc_movePattern_byDstPos(ball, deltaT){
	
	   
	   let distX  = (ball.userPos.x - ball.pos.x)  
       let distY  = (ball.userPos.y - ball.pos.y)	   
				
		ball.pos.x +=ball.velocity.x*deltaT 
		ball.pos.y +=ball.velocity.y*deltaT
		
				
		let dist = Math.sqrt(distX*distX + distY*distY)
	
	
	    if(dist < 5){
		   
		     let maxIdx, dstSlotPos
		   
		     let refdist = rock_radius*2			 
		   		   
		      ball.pos.x = ball.userPos.x 		   
		      ball.pos.y = ball.userPos.y					   
			  
			    ball.pattern_dst_Idx++		 
						
			let dstPosArray = getDstPosArray(ball.movePatternIdx)			
			
			if(dstPosArray != null){
				
		  	   maxIdx = dstPosArray.length -1 				
			
			}
			else {
			
			   gPrint('dstPosArray not found')
               return 			
			}

			if(ball.pattern_dst_Idx > maxIdx){
				
				 if(ball.hasProp(ball_prop_dstPos_loop)){
			 
					   ball.pattern_dst_Idx = 0	 
				  }
				  else {
					  
					  //중지  
					  ball.isWaitForRemove = true 
					  gNumOfRemainPatternEnemy--
					  
					  return
					  
				  }
				
			}
    
	
		  	   let curIdx = ball.pattern_dst_Idx			
			   //slotPos
			   
			  let beginSlotPos   
			  let dst_pos 
			   
			   dstSlotPos =  dstPosArray[curIdx]
               dst_pos = getCanvasPos(dstSlotPos.x + ball.patternRefPos.x-1, dstSlotPos.y + ball.patternRefPos.y-1)
			   
			 ball.userPos.x = dst_pos.x 
			 ball.userPos.y = dst_pos.y
				 
			   
			   let distX = ball.userPos.x - ball.pos.x 
			   let distY = ball.userPos.y - ball.pos.y 
			   let len = Math.sqrt(distX*distX + distY*distY)
			   
			   
			   let speed = 0.2
			   if(ball.level == 1){
				   
			   }else if(ball.level == 2){
				   speed = 0.2
			   }else if(ball.level == 3){
				   
   				   speed = 0.4

			   }
			   
			   if(len > 0){
			   
				   ball.velocity.x = (distX/len)*speed
				   ball.velocity.y = (distY/len)*speed 
			   }
			   else if(len==0){
				   
				   ball.velocity.x = 0.0
				   ball.velocity.y = 0.0
				   
			   }
	 
	   }			   
	
}

//===========================
//
//==========================
function getDstPosArray(patternIdx){
	
	 if(patternIdx== move_pattern_u){
 
		  return pattern_u_dst_pos_array
	  }	  
	 else if(patternIdx== move_pattern_v){
 
		  return pattern_v_dst_pos_array
	  }	  
	  else if( patternIdx== move_pattern_line){
		  
		  return pattern_line_dst_pos_array
		  
	  }
      else if(patternIdx == move_pattern_line_v){
		  
		  return pattern_line_v_dst_pos_array
		  
	  }
	  else if( patternIdx == move_pattern_tri_1){
		  
		return pattern_tri_1_dst_pos_array
		  
	  }
	  else if( patternIdx== move_pattern_tri_2){
		  
		 return pattern_tri_2_dst_pos_array
	  }				  
	  else if(patternIdx == move_pattern_wave_h){
		  
		 return pattern_wave_h_dst_pos_array
		  
	  }
	  else if(patternIdx == move_pattern_wave_v){
		   
         return pattern_wave_v_dst_pos_array		  
	  }
	  else if(patternIdx == move_pattern_rect){
		   
         return pattern_rect_dst_pos_array		  
	  }

	  
	
	return null
}

function getRandomMovePattern(){
	
	let randV = getRandomVal(1, 100)
	
	if(randV <= 30){
		
		return move_pattern_u
		
	}
	else if(randV <= 60){
		
		return move_pattern_s
		
	}
	else {

		return move_pattern_circle		
		
	}
	
}

//==============================
function proc_movePattern_circle(ball, deltaT){	
	
		let r = ball.customRadius //  move_c_radius_level_3				  		
		ball.circleMoveAngle += move_c_speed_level_2					
	
		let angleR = ball.circleMoveAngle*(Math.PI/180)
		
		let dst_x =  Math.cos(angleR)*r - Math.sin(angleR)*0  + ball.circleCenter.x 	
		let dst_y = Math.sin(angleR)*r  + Math.cos(angleR)*0 + ball.circleCenter.y 
			
	//	let delta_x = (dst_x - ball.pos.x)/10 		
	//	let delta_y = (dst_y - ball.pos.y)/10 		
							
		ball.pos.x  = dst_x 
		ball.pos.y =  dst_y 
	
		ball.anchor.x = ball.pos.x
		ball.anchor.y = ball.pos.y
	
	
}


function proc_movePattern_circle2(ball, deltaT){

      if(ball.movePatternState == 0){

	    let r = ball.customRadius			  		
		ball.circleMoveAngle += move_c_speed_level_2					
	
		let angleR = ball.circleMoveAngle*(Math.PI/180)
		
		let dst_x =  Math.cos(angleR)*r - Math.sin(angleR)*0  + ball.circleCenter.x 	
		let dst_y = Math.sin(angleR)*r  + Math.cos(angleR)*0 + ball.circleCenter.y 
							
		ball.pos.x  = dst_x 
		ball.pos.y =  dst_y 
	
		ball.anchor.x = ball.pos.x
		ball.anchor.y = ball.pos.y
	
		   if(ball.circleMoveAngle > 720){
			   
			   ball.movePatternState = 1 
		   }
	  }
	  else if(ball.movePatternState == 1){
		  
		  let dstX = gClientW + 60  		  
		  
		  let deltaX = (dstX - ball.pos.x)/10
		  ball.pos.x += deltaX  		  		  
		  
		   if(deltaX < 4){
			   
			   ball.pos.x  = dstX 			   
			   ball.isWaitForRemove = true 
		  	  gNumOfRemainPatternEnemy--
			   
			  return 
		   }
		   else {
		   
		   	  ball.anchor.x = ball.pos.x
		    }

	  }


}	


let gSoundEffectFlag = 0

function proc_petBall_collide_enemyGuard(petBall, eGuard){
				

    //충돌반대방향으로 				
	 let respV_info = get_ball_responseV_d1(petBall, eGuard)
	 let respV = respV_info.respV

	 petBall.power--
	 
	 gPrint('petBallPower: ' + petBall.power)
     eGuard.isWaitForRemove =true    
	 
  
		
	 gNumOfKilledPatternEnemy++
	 gNumOfRemainPatternEnemy--
	 
	 
	 
	 //해당 그룹이 모두 killed인지 체크	
	 //  bullet.movePatternGroupIdx 
	 let groupIdx = eGuard.movePatternGroupIdx 
	 
	 let groupInfo  = getPatternEnemyGroupInfo(groupIdx)
	 
	 if(groupInfo!=null){
		 
		 groupInfo.killCount++
		 
		 if(groupInfo.killCount == groupInfo.numSpawn){
			 
			 gPrint('killCount == numSpawn')
			 
			 if(groupInfo.itemPhoto == 1){
			 
			     let ranV = getRandomVal(1, 100)
			 	 
				 let item = spawnItem(eGuard.pos.x, eGuard.pos.y, r_item_photo , null)
				 item.lifeT = 5*1000
				 
			 }
			   
			 
		 }
		 
	 }
	 
	 
	   let effx = eGuard.pos.x 
	   let effy = eGuard.pos.y 
	   addDebrisEffect(effx, effy, debris_enemyBullet)
	   
	   //======================
	   //score
	   gUserScore += 2
       let spr = addScoreSpr(effx, effy, 2)
	   spr.colorStr = '#FD9301'				   
	   //=====================
	   
	 

      if(petBall.rscIdx == r_defense_ball){
		  
	      let speed =  getVecLength(petBall.velocity)
		  
		  let rePos = respV_info.rePos 
		  
		  petBall.pos.x = rePos.x 
		  petBall.pos.y = rePos.y 
		  
		  petBall.velocity.x = respV.x*speed
		  petBall.velocity.y = respV.y*speed
		  		  
	  }
	  else {
		  
		  if(petBall.power < 1.0){
		  
			petBall.setState(ballstate_fallingDown)	
			force_post_ball_interact()			
		  }
			
			petBall.velocity.x += respV.x 
			petBall.velocity.y += respV.y 
		  
		  
	  }
	   
	   
		playSoundEffect(sound_broken)
		
	   if(gSoundEffectFlag == 0){
	
		playSoundNote(sound_note_si)
		
		gSoundEffectFlag = 1

	   }else {
	
	     playSoundNote(sound_note_la)		
		 gSoundEffectFlag = 0
		   
	   }
	
}


//======================
//
//
//=====================

//idx:0
let ttc_0_seq = [] 

// 3초 후에 -40도 변경
//-------3s-------------------------
function initTentacle(){
	
	gPrint('----initTentacle----')
	
	//elasp angle	
	ttc_0_seq.push( {tick: 3, angle: -40} ) 
	//다음 3초후 0도
	ttc_0_seq.push( {tick: 3, angle:  0} ) 
	

  gPrint('seqLength: ' + ttc_0_seq.length +'개')
	
}

function beginTentacle(){
	
	
	
}



function updateTentacle(ttc){
   
  
   
   
}




