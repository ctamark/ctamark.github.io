
//slot idx 단위(zero-based)
function getCanvasPos(slotX, slotY){
	
	     let slotSize = rock_radius*2			 
         let xoffset = (gClientW - slotSize*9)/2     

         //let x = xoffset + slotX*refdist 
         //let y = gPlayableSize.y + 20+ slotY*refdist 		 
		 let	xp = xoffset + rock_radius + slotX*slotSize 
		 let	yp = gPlayableSize.y +  rock_radius + slotY*slotSize
        
		
        return {x: xp, y: yp}			
}

function getBrowserName(){
	
	const agent = window.navigator.userAgent.toLowerCase()
	let browerName 
	
	if(agent.indexOf('chrome') > -1 && window.chrome){
				
		browerName = 'chrome'
		
	}
	else if(agent.indexOf('safari') > -1 ){

		browerName = 'safari'
			
	}
	else {
		
		browerName = 'other'
	}
	
	return browerName
		
}


function getLanguage(){
	
  var userLang = navigator.language || navigator.userLanguage;
  return userLang;
	
}

const img_photo = 0 
const img_classic = 1
const img_random = 2 



function getPrizeImgName(type=2){
	
	 //못 찾을 경우 default값
	 let fname = "c-0001"
	
	  if(type == img_classic){

	      fname = gValidClassicNames.shift() 
	 }
	 else if(type == img_photo){
		  
          fname = gValidPhotoNames.shift()
		  
	  }
     else if(type == img_random){
		 
		 //너무 photo만 노출되어 수정
		 
            let randV = getRandomVal(1, 100)
			if(randV <= 70){
				
				if(gValidClassicNames.length > 0){
								
                   fname = gValidClassicNames.shift()					
				 }
				
			}
			else {
				
				 if(gValidPhotoNames.length > 0){
				
				    fname = gValidPhotoNames.shift()	
				 }
				 
			}
           
  	 }		
		 		
    return fname 		
	
}



//일반적으로 조건 판단 요소가 많아질수록 switch-case 구문이 성능이 좀 더 좋은 편
//문자열을 생성할 때는 되도록 String 객체보다는 리터럴을 사용하는 것이 좋습니다.
//ex)  let str = '문자열' 
function getlength(number) {
	
    return number.toString().length;
}

// 4, 3자리 
function getNumberStr(number, numDigit){

   let numStr = number.toString() 
   let numZero = numDigit - numStr.length 

    for(let i=0; i < numZero; i++){
 
       numStr = '0' + numStr 
	}		
	
	return numStr 	
}


function getItemRscIdx_random(){
	
	let   rscIdx = r_none

	  let randV= getRandomVal(1, 100)

	  if(randV <= 10){
	   
		  rscIdx = r_item_bomb
	   }
	  else if(randV <=30){
	   
		  rscIdx = r_item_smaller
	   
	  }else if(randV <= 80){
	  
		  rscIdx = r_item_eye   	  
	  }
	  else if(randV > 90 && randV <= 94){
		  //4%
		  rscIdx = r_item_photo
		  
	  }else {
		  
		  //생성안함
	  
	  }
	  	  	   
	   return rscIdx
}
  
 
  
  
function getFireAngle(tx, ty){
	

	let diffX = tx - gClientW/2 
	let diffY = ty - gNextBallRefY
	let len = Math.sqrt(diffX*diffX + diffY*diffY)
	
	let dirV = {x:diffX/len, y:diffY/len}			
	
	let refV = {x:0, y:-1.0}
	let dot = dirV.y*-1.0  
	let angleD = Math.acos(dot)*(180/Math.PI) 
	

    return angleD 	
	
}

// 0: (1, 0) 
// 90: (0, 1)

function rotateVec(refx, refy, angle){

  let angle_r = angle*(Math.PI/180)

   let resV = {x:0, y:0}
   resV.x = Math.cos(angle_r)*refx - Math.sin(angle_r)*refy
   resV.y = Math.sin(angle_r)*refx + Math.cos(angle_r)*refy

   return resV

}


function rotateVec2(vec, angle){

   let angle_r = angle*(Math.PI/180)

   let resV = {x:0, y:0}
   resV.x = Math.cos(angle_r)*vec.x - Math.sin(angle_r)*vec.y
   resV.y = Math.sin(angle_r)*vec.x + Math.cos(angle_r)*vec.y

   return resV

}

function getVecLength(vec){
	
	let len = Math.sqrt(vec.x*vec.x + vec.y*vec.y)
	
	return len 	
}

function getClampVec(vec, maxLen){
	
  let len = Math.sqrt(vec.x*vec.x + vec.y*vec.y)
  
  // gPrint('getClampVec: len--->' + len)	
   
  if(len > maxLen){
	
 
	  

   let resV = {x:0, y:0}
   resV.x = vec.x/len	  
   resV.y = vec.y/len 	
 
   resV.x = resV.x*maxLen 
   resV.y = resV.y*maxLen 
   
   return resV	  
  }
  else {
 	
	 return vec 
  }  
  
}



//(refx,refy 단위벡터)
function getAngle(refx, refy, x1, y1){

       let refV =  {x: refx, y: refy}
	   
	  let mag = Math.sqrt(x1*x1 + y1*y1)
                                    
	  let dot = (refV.x*x1 + refV.y*y1)									
	  let angleR = Math.acos(dot/mag)

	  let angle = angleR*(180/Math.PI)								

    return angle 									
}


//10개
//let prepos_array_used = [] 
let prepos_array = []

let preposCurIdx = 0

function shuffle(array) {
  array.sort(() => Math.random() - 0.5);

}

function resetEnemyBulletPrepos(){
      
   for(let idx=0; idx< 12; idx++){
  
     prepos_array.push(idx)
 
   }
   
   shuffle(prepos_array) 
   preposCurIdx	 = 0   
   gNumEnemyBullet = 0

}	

function getNumOfEnemyBulletByGroupIdx(idx){
	
	let curBall 
	let count = 0
    for(let i=0; i < gBalls.length; i++){
	
	   curBall = gBalls[i]
   
	   if(curBall.rscIdx == r_enemy_bullet && curBall.movePatternGroupIdx == idx){
		   
			count++		   
	   }
		
	}
	
	
	return count
	
	
}


function getEnemyBulletPrepos(){

   if(preposCurIdx >= prepos_array.length){
	
	   preposCurIdx = 0
    }
	
	let idxVal = prepos_array[preposCurIdx]
    preposCurIdx++
	
	let ballsize = rock_radius*2
	
	//6개 2줄
	let pos = {x: 0, y: 0}

	let slotX =  idxVal%6 
	let slotY = 5 + idxVal/6  	
	
	//gPrint('slot pos' + slotX + ', ' + slotY)
	
	pos.x = rock_radius + slotX*ballsize
	pos.y = gPlayableSize.y +  slotY*ballsize 
	
	if(slotX == 2 || slotX == 3){
		
		pos.y += 20		
	}
	else if(slotX == 0 || slotX == 5){
		
		pos.y -= 20
	}
		
	    	
   return pos 	
	
}


function showDivElmt(idStr , isShow){
	
	let div = document.getElementById(idStr)
	
	if(div == null || div == undefined){
      return 
	}

   if(isShow){
	   
	   div.style.display = 'block'
   }
   else {
	   
	   div.style.display = 'none'	   
   }
    		
  return div  			
}


/*
rockArray: [
	
	    { x: 3.5, y: 3, type: rock_c_r_b, group:0 },
        { x: 3.5, y: 3, type: rock_c_r_b, group:0 }
	]	
*/		

function createRockGroup(x, y, pattern_idx){
	
	let group =  new  groupEntity()
	//	
	//<-----[b , b, b]---->  
	
	
	
	
	
	group.updateBound()
	
	return group 
	
}


function getAttachedRock(refx, refy, refRadius, printInfo=false){
	
     let curRock,  len = gBalls.length 
	 let diffx, diffy 
	 
	 gPrint('begin --- getAttachedRock, ' + len)
	 
     for(let i=0; i < len; i++){

	   curRock = gBalls[i]
   
	   if(curRock.rscIdx !=r_rock_01 && curRock.rscIdx != r_rock_wrld_bound){
		   
		   continue 
	   }
	   
	    gPrint('rock, ' + curRock.id)
	   
	   diffx = refx - curRock.pos.x 
	   diffy = refy - curRock.pos.y
	   
	   
       let len = Math.sqrt(diffx*diffx + diffy*diffy)	   
	   
	   let refLen = rock_radius + refRadius
	   
  	   if(printInfo==true){
		   
		   gPrint('len:  ' + len + ', ' + 'refLen: ' + refLen)
		   
	   }

	   
	   if(len < refLen){
		   
		   return curRock
	   }
	  			
	}
	
	return null 	
	
	
}


function getEmptyPos(refx, refy){

//refy 기준으로 최대 5*60 

   let rPos = {x: 0, y: 0}
   
   rPos.x += refx +getRandomVal(-30, 30)
   rPos.y += refy +getRandomVal(100, 300)
   
  return fPos	
}


//================
let earthQuakeST = 0
let earthQuakeCount = 0
let isEarthQuake = false 

let bg_offsetX = 0
let bg_offsetY = 0

function beginEarthQuake(){
		
	earthQuakeST = gAppCurT 
	isEarthQuake = true 
    bg_offsetX = getRandomVal(-10, 10)
	bg_offsetY = getRandomVal(-6, 6)		
	
	earthQuakeCount = 0 
		
}

function updateEarthQuake(){
	
	if(gAppCurT >= earthQuakeST + 500){
		
		isEarthQuake = false 
				
	}
	else {
		
		earthQuakeCount++
	
	     if(earthQuakeCount%5 == 0){
			 
			 bg_offsetX = getRandomVal(-5, 5)
			 bg_offsetY = getRandomVal(-5, 5)			 
		 }
		
	}
		
}


function getNearestMonster(refX=0, refY=0){
  
    let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	   curBall = gBalls[i]
	   	   
	   
		   if(curBall.rscIdx == r_mon1 || 
			  curBall.rscIdx == r_mon2 ||
              curBall.rscIdx == r_mon2_child ||			  
			  curBall.rscIdx == r_mon3 ||
              curBall.rscIdx == r_mon_bull ){
				  
               if(curBall.state ==  ballstate_small_toDeath){
               
			          continue 
 			   }				   
			   
			   return curBall		   
		   }
		
	}
	
	return null 
	
}

//=====================
//
//=====================
function getFirstMonster(){
  
    let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	   curBall = gBalls[i]	   	   
	   
	    if(curBall.rscIdx == r_mon1 || 
		   curBall.rscIdx == r_mon2 ||
		   curBall.rscIdx == r_mon2_child ||			  
		   curBall.rscIdx == r_mon3 ||
		   curBall.rscIdx == r_mon_bull 
		   || curBall.rscIdx == r_mon_eye
		   || curBall.rscIdx == r_mon_redcat ){
			  
			   if(curBall.state ==  ballstate_small_toDeath){
			   
					  continue 
			   }				   
		   
		   return curBall		   
	    }
	
	}
	
	return null 
	
}



function getFirstBallByRscIdx(rscIdx){
	
	 let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	   curBall = gBalls[i]
	   
		   if(curBall.rscIdx ==rscIdx){
			   
			   return curBall		   
		   }		
	}
	
	return null 	
	
}


function getFirstBreakableRock(){
		
    let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	   curBall = gBalls[i]
	   
	   if( curBall.hasProp(ball_prop_breakable) ){
		   
		   return curBall
	   }
	   
	   if( curBall.rscIdx ==  r_rock_breakable ||
	       curBall.rscIdx ==  r_rock_float_anchor ||   
           curBall.rscIdx ==  r_rock_reflect ) {
		   
		   return curBall
	   }
	   
	   
	}
	
	return null 	
	
}


function playMatchEffect(refX, refY){

    let rand = getRandomVal(0.0, 1.0)
	if(rand <= 0.3){

		playSoundEffect(sound_match_01)
			
     }else if(rand <= 0.5){

		playSoundEffect(sound_match_02)
			
	 }else if(rand <= 0.7){
		 
		playSoundEffect(sound_match_03)
		 
	 }else {

		playSoundEffect(sound_match_04)
			
	 }
	
	
}



//===============

function preloadSndObj(rscIdx, numObj=1){
	
	
	let fname = gSoundNames[rscIdx]
	if(fname == null || fname == undefined){
	
       	console.log('fname error ')	
		return 
	}
	
	//console.log('preloadSndObj ' + fname)

    let sndObj ,  audio

   for(let i=0; i < numObj; i++){
	
	// 새롭게 로딩해야 하는 경우   
	sndObj = getEmptySndObj()
	
	if(sndObj == null){		
		//gPrint('emptySndObj not found')	
	    return 	
     }
	 
	// gPrint('emptySndObj.id ' + sndObj.id)
	
     sndObj.rscIdx = rscIdx 
		
	let audio =  sndObj.audio
	audio.volume = 0  
	audio.src = fname; // 음원 파일 설정
	audio.load() //오디오 객체를 리로드
	
	  audio.addEventListener('ended',  function(){		 
	   
	   //console.log('ended: byPreload: ' + fname)	   
	   //this.load()
	   //this.pause()
	   
	  });
	
    /*
     audio.addEventListener('canplaythrough',  function(){		 
	   console.log('canplaythrough: byPreload: ' + fname)	   
	  });
			
	 audio.addEventListener('pause',  function(){		 
	   console.log('pause: byPreload: ' + fname)	   
	  });
	
	audio.addEventListener('loadeddata', () => {
  
     console.log('loadeddata byPreload: ' + fname);
	
	})	
	*/
	
	 audio.loop = false 		 
	 
   }

		
}


function releasePreloadSndObj(rscIdx){

	for(let i=0; i < gSoundObjArray.length ; i++){
	
		 sndObj = gSoundObjArray[i]            
		
		 if( sndObj.rscIdx == rscIdx ){
			
			 sndObj.rscIdx = -1
								 
		 }
				
	}	
	
}



//사용가능한 같은 rscIdx를 사용하는 SndObj가 있는지 체크 
function getLoadedSndObj(rscIdx){
	
     let sndObj
	 
	// gPrint('getLoadedSndObj')

	for(let i=0; i < gSoundObjArray.length ; i++){

    	   sndObj  = gSoundObjArray[i]
		   		 
		   if(sndObj.rscIdx != rscIdx){
			   
			   continue 
		   }
		   		   
           let audio =  sndObj.audio 
		//    console.log('readyState ' + audio.readyState)
			   	
    	   if(audio.ended || audio.paused){
			   
			   return sndObj
		   }
		   else {
		
         //     console.log('same rscIdx soundObj loaded but playing')				
		   }

	  }
	  

   return null 
}


function getEmptySndObj( ){

     let sndObj

	for(let i=0; i < gSoundObjArray.length ; i++){

    	   sndObj  = gSoundObjArray[i]
		
			//한번도 사용되지 않은 sndObj인경우  
			if(sndObj.rscIdx == -1){
				
				// gPrint('getEmptySndObj SndObj.rscIdx == -1  idx: ' + i)
				    return sndObj
			}
			
	  }

   return null 
}



//-------------------------------


/* 
 src	음원파일 경로 : "경로/파일명.확장자"
volume	볼륨 : 0~1
loop	반복 여부: true | false
autoplay	자동재생 여부: true | false
muted	음소거 여부: true | false
paused	일시정지 여부: true | false
ended	재생완료 여부: true | false
duration	음원의 전체 길이(초 단위)
currentTime 음원의 현재 재생 위치(초 단위)

 
	
 */
 
//사용자가 버튼 클릭과 같은 작업을 통해 play() 메서드를 호출해야만 음원을 재생할 수  
// 시나리오: play(hit-01)-->play(hit-01)-->play(hit-02)
//const sound_prop_reserved   
function playSoundEffect(rscIdx=0, volume = 0.3){
  
    
  if(gIsAndroid==false){
	  
      ios_playSoundEffect_JS(rscIdx)
	  
	  return 	  
  }
  //------------  
  //android
  //-----------
	  
  try{	  

      android.onPlaySoundEffect_JS()	  
	  
	  return
  }
  catch{
	  
  }
	  
	  
  
   let fname = gSoundNames[rscIdx]
  
   if(fname == null || fname == undefined){
	  
 	   gPrint('playSoundEffect' + 'rscIdx ' + rscIdx + ', ' + fname + ' not found')
	   return null
   }
   
     gPrint('playSoundEffect ' + fname)
   
   //사용가능한 이미 로드된 sndObj가 있는지 체크
   let sndObj = getLoadedSndObj(rscIdx)   
   if(sndObj != null){
	   
	 

      sndObj.audio.currentTime = 0 	
	  sndObj.audio.volume = volume 
      sndObj.audio.play()	  
	 
	 // gPrint('preloaded sndObj found id: ' + sndObj.id + 'play()')
	  
	  return sndObj.audio
   }
   else {
	
   //없는 경우 그냥 return 하고 play하지 않기	   	
   //gPrint('available preloadedSndObj not found: ' + fname)
    
	return 
      
   }
   
  
   // 새롭게 로딩해야 하는 경우   
    sndObj =  getEmptySndObj( )   
	
	sndObj.rscIdx = rscIdx 
   
	sndObj.audio.src = fname; // 음원 파일 설정
	sndObj.audio.load() //다시로드 


	//sound.play(); // 음원 재생
	//sound.pause(); // 일시 정지	
	//sound.load() //오디오 객체를 리로드
	
     sndObj.audio.volume = volume
	 sndObj.audio.loop = false 		 
	 sndObj.audio.play()


    return sndObj.audio
}


let _hitSoundNoteRscIdx = 0 
function getHitSoundRscIdx_random(isSoundNote){
	
	 //let rand_idx = Math.floor( Math.random(3) )
	 
	let sound_idx 
	if(isSoundNote){
		
         sound_idx = sound_note_hit + _hitSoundNoteRscIdx%3 
	}
	else {

         sound_idx = sound_hit + _hitSoundNoteRscIdx%3 

	}	
	
	_hitSoundNoteRscIdx++
	

     return sound_idx 	 	 	
}


let _fireSoundNoteRscIdx = 0 
function getFireSoundRscIdx_random(isSoundNote){
	
	
	let sound_idx 
	if(isSoundNote){
		
         sound_idx = sound_note_hit + _hitSoundNoteRscIdx%3 
	}
	else {

         sound_idx = sound_hit + _hitSoundNoteRscIdx%3 

	}	
	
	_fireSoundNoteRscIdx++
	

     return sound_idx 	 	 	
}


//timming이 중요한 경우
function playSoundNote(note_idx){
	
	if(_useSoundNote==false){
		
		return 
	}
	
	if(gAppState != appState_play){
		
        gPrint('playSoundNote canceled (<----not appState_play)')
		return 
	}
	
   let rscIdx
 
   if(!gIsDevice ){
	   	   	   
       rscIdx = getHitSoundRscIdx_random(false)
       playSoundEffect(rscIdx)
	  
	   return 
   }
   
   rscIdx = note_idx 
   
   if(note_idx == sound_note_fire || note_idx  == sound_note_broken){
	   
	   
	   
	   
	   
   }
   else { 
	   
	 
	    rscIdx = getHitSoundRscIdx_random(true)
	   	   
   }
   
   

	if(gIsAndroid){
					
		  try{		
 		           android.onPlaySoundNote_JS(rscIdx)
								
			}
			catch {
								
			}
	
       return 	
	}
	else {
	
	
	   ios_playSoundNote_JS(rscIdx)
	
	}
	
	
}

function playSoundNoteByRscIdx(rscIdx){
	
	 if(rscIdx == r_rock_float_anchor){

  	         playSoundNote(sound_note_mi)
				 
	 }
	 else if (rscIdx == r_rock_reflect){
			
			  playSoundNote(sound_note_sol)						
	 }
	 else {
		 
			 playSoundNote(sound_note_si)					
	  }
	  
}

function stopAllSoundNote(){
	
	if(gIsAndroid){
		
		
	}
	else {
		
		ios_stopAllSoundNote()
		
	}
	
}

function playMusicByFname(fname, fromStart=false){
	 	 
	 if(gIsAndroid==false){
		 
	   ios_playMusic_JS(fname, fromStart)	 
		 
		 return 
	 }
	 	 
    if(gCurMusic != null){

      if(gCurMusic.src.indexOf(fname) != -1){
		
		 if(fromStart){

		      gCurMusic.currentTime = 0			 
		 }
		   gCurMusic.play() 	
		 		 
		  return 
	  }
	  
	  //현재 음악 중지 
	  gCurMusic.pause()	  
	  gCurMusic = null
	}		
		  
  
     gPrint('playMusicByFname: ' + fname)   
	 		
		
	gCurMusic = new Audio()
	gCurMusic.src = fname 
    gCurMusic.load()
	gCurMusic.loop = true 
	gCurMusic.volume = 0.2
    gCurMusic.play() 	
		
}

function stopCurrentMusic(){
	
	if(gIsAndroid){
		
		gCurMusic.pause()		
	}
	else {
		
		ios_stopCurrentMusic_JS()		
	}
		
	
}



//==============
const debris_rock = 0
const debris_diamond = 1 
const debris_reflect   = 1 
const debris_enemyBullet = 2

const debris_reflect3 = 3 

function addDebrisEffect(refX, refY, type=0){

	 let spr
	 let rX, rY 
	 let size= 12
     for(let i=0; i < 6; i++){

		  //spr = new sprite(refX, refY, 2000)
		  spr = getNewSpriteFromPool()
		  spr.pos = {x: refX, y: refY}
		  spr.lifeT = 2000
		  		  
		  spr.img = gEffectSpr
		  
		  spr.setBlendType(spr_blend_sourceOver)

          rX = refX +getRandomVal(-15, 10)
		  rY = refY + getRandomVal(-15, 10)
        		  
		 //------------------		  
		  let motion = new sprMotion(rX, rY)
		  
		  if(i == 0 || i==2 || i == 5 ){
			  
			  if(type == debris_rock){			  
				 spr.addFrame(0,0,64,64)
			  }
			  else if(type == debris_diamond){
	
			      spr.addFrame(320,0,64,64)
		
			  }else if(type ==debris_reflect3){
				  
				   spr.addFrame(260, 140, 32, 32)
				  
			  }else {
				  
			      spr.addFrame(256, 64, 64, 64)
			  }
			  
			  	  spr.setCSize(size, size)		
		       			   
		   motion.velX = getRandomVal(+0, +10)
		   motion.velY = getRandomVal(-5,  -8)		
			   
		  }
		  else {
			 
             if(type == debris_rock){			 
		       spr.addFrame(0,64,64,64)
			   spr.setCSize(size, size)
			 }			 
			 else if(type == debris_diamond){
				 
			     spr.addFrame(384,0,64,64)
			     spr.setCSize(size, size)		
			 }
			 else if(type == debris_reflect3){
				 
			     spr.addFrame(292,140,32,32)				 
			 }
			 else if(type == debris_enemyBullet ){
				 
				 if(i==1){
				 
				     spr.addFrame(320, 64, 64, 64)				 
				 }
				 else {

				     spr.addFrame(384, 64, 64, 64)				 
					 
				 }
				 
				 
			     spr.setCSize(size*1.2, size*1.2)		
			 }
			 
			 
			 motion.velX = getRandomVal(-0, -10)
		     motion.velY = getRandomVal(-5,  +5)		
		  }		  
		  		  
		  motion.useGravity = true 
		  motion.angleSpeed = 5
		  
		   //-----
		   spr.motion = motion 
		  //-------------------	
		   spr.begin()
			
		   gEffectSprites.push(spr) 
		  
		  }

}

function addBlackholeEffect(refX, refY){
	
		
 		  let spr = addEffectSpr(refX, refY, 1 , 250, 500)	 	 

		  spr.blendType = spr_blend_sourceOver
		  spr.isLowLayer = true 
	

}



function attachSunRayEffect(ball, size){
	
	    let refX = ball.pos.x  
	    let refY = ball.pos.y  
	
         let spr = new sprite(refX, refY,  0)
		  		  		  
		  spr.img = gEffectSpr		  
		  
	      spr.addFrame(384, 128, 128, 128)

		  spr.setCSize(size, size)

          //rX = refX// +getRandomVal(-15, 10)
		  //rY = refY// + getRandomVal(-15, 10)
        		  
		 //------------------		  
		  let motion = new sprMotion(refX, refY)
          motion.velX = 0
		  motion.velY = 0		
		  motion.useGravity = false 
		  motion.rotSpeed = 1
		  
		  //-----
		  spr.motion = motion 
		 //-------------------	
		  spr.begin()
			
		  gEffectSprites.push(spr) 
		  
    
		  spr.blendType = spr_blend_sourceOver
		  spr.isLowLayer = true 	
		  
		  
		  ball.effectSpr = spr 
		  
		  return spr 

}

function attachEffectToDefenseBall(defenseB, eff_idx=0){
	
	let refx = defenseB.pos.x 
	let refy = defenseB.pos.y 


   // let spr =  addEffectSpr_withoutMotion2(refx, refy, 192, 0, 64, 64, rock_radius*2*4, 0)	
    let spr =  addEffectSpr_withoutMotion2(refx, refy, 192, 128, 64, 64, rock_radius*2*3, 3000)	
	   		  
    return spr 	
}

function attachEffectToBall(targetB, srcX, srcY, srcW, srcH, size, lifeT=3000, rotSpeed=0){
	
	let refx = targetB.pos.x 
	let refy = targetB.pos.y 

   // let spr =  addEffectSpr_withoutMotion2(refx, refy, 192, 0, 64, 64, rock_radius*2*4, 0)	
    let spr =  addEffectSpr_withoutMotion2(refx, refy, srcX, srcY, srcW, srcH, size, lifeT)	
	   		  			  
    targetB.effectSpr = spr 
    spr.setMoveType(spr_move_byCustom)
   			  
			  
    return spr 	
}




function addMonsterDamageTextSpr(refX, refY, damage){
	
	    let numSpr = Math.floor(damage/2)

         for(let i=0; i < numSpr; i++){
         
		 let effectSpr = new sprite(refX, refY, 1000)

		  effectSpr.pos.x += getRandomVal(-5, +5)
		  effectSpr.pos.y += getRandomVal(-5, +5)
		  
		  let motion = new sprMotion(effectSpr.pos.x, effectSpr.pos.y)
		 
	 	  motion.velX = getRandomVal(-5, +5)		  
		  motion.velY = getRandomVal(-5, +5)
		 
			 let dstX =  gClientW/2
			 let dstY =  gScoreRefY;//gPlayableSize.y - 5
			 
			 motion.isDstMove = true 
			 motion.dstPos = {x: dstX, y: dstY}
		 
	        effectSpr.motion = motion


	      effectSpr.msg = '+2'
		  
		  //---------------------
 		  effectSpr.isForScore = true 
		  effectSpr.userData = 2
          //--------------------		  

		  
		  
          effectSpr.setMoveType(spr_move_up)
		  effectSpr.setFontInfo(font_big, '#f00')
		  
		  effectSpr.begin()
	
        	gEffectSprites.push(effectSpr) 
		  
		 }
		  
		  
}


function addScoreSpr(refX, refY, score){
	
	let  text = '+' + score
	
	let  textSpr = addEffectTextSpr(refX, refY, text, 3000)
	textSpr.isForScore = true 
	textSpr.userData = score 	
	
	return textSpr 
}


//
function addEffectTextSpr(refX, refY, msg, lifeT=1000, useDstPos=true){
	
//	      let textSpr = new sprite(refX, refY,  lifeT)
		  
	      let textSpr = getNewSpriteFromPool()
		  textSpr.pos.x = refX
		  textSpr.pos.y = refY 
		  textSpr.lifeT = lifeT
		  
		  		  		  
		  textSpr.colorStr = '#0F0'
		  textSpr.msg = msg 
		  textSpr.fontKind =font_big
		  
		  //---
		  textSpr.blendType = spr_blend_sourceOver
		  //---
		  
	 	  let motion = new sprMotion(textSpr.pos.x, textSpr.pos.y)

		  
		 if( useDstPos){
			 
			 let dstX =  gClientW/2
			 let dstY =  gScoreRefY//gPlayableSize.y - 5
			 
			 motion.isDstMove = true 
			 motion.dstPos = {x: dstX, y: dstY}		 		  
		  }
		  else {
		    
 			 motion.useGravity  = true 			  
			 motion.velX = getRandomVal(-5, +5)		  
		     motion.velY = getRandomVal(0, +5)
			  
		  }
		  
		  textSpr.motion = motion
		
		  textSpr.begin()

		  
		  gEffectSprites.push(textSpr) 

          return textSpr  			
		  
}


function addEffectTextSprEx(refX, refY, msg,  velX, velY, isGravity, lifeT=1000){
	
	      let textSpr = new sprite(refX, refY,  lifeT)
		  		  		  
		  textSpr.colorStr = '#0F0'
		  textSpr.msg = msg 
		  textSpr.fontKind =font_big
		  
		  //---
		  textSpr.blendType = spr_blend_sourceOver
		  //---
		  //motion을 사용하는 경우   useLocalCoord = true , useCanvasCoord = false 
	 	  let motion = new sprMotion(textSpr.pos.x, textSpr.pos.y)
		  motion.velX = velX	  
		  motion.velY = velY		  
		  motion.useGravity  = isGravity
		  motion.angleSpeed = 0
		  
		  textSpr.motion = motion

		
		  textSpr.begin()
		  
		  gEffectSprites.push(textSpr) 

          return textSpr  			
		  
}


//lifeT 0(infinite)
function addEffectSpr(refX, refY, effectIdx, size, lifeT=1000){
	
	       
	      let spr = new sprite(refX, refY,  lifeT)
		  		  		  
		  spr.img = gEffectSpr
		  
		  let slotx = effectIdx%8
		  let sloty = Math.floor(effectIdx/8)
		  
	      spr.addFrame(slotx*64, sloty*64, 64, 64)

		  spr.setCSize(size, size)

          rX = refX// +getRandomVal(-15, 10)
		  rY = refY// + getRandomVal(-15, 10)
        		  
		 //------------------		  
		  let motion = new sprMotion(rX, rY)
          motion.velX = 0
		  motion.velY = 0		
		  motion.useGravity = false 
		  //-----
		  spr.motion = motion 
		 //-------------------	
		  spr.begin()
			
		  gEffectSprites.push(spr) 
		 	
          return spr  			
		  
}

function addEffectSpr_withoutMotion(refX, refY, effectIdx, size, lifeT=1000){
	
	       
	      let spr = new sprite(refX, refY,  lifeT)
		  		  		  
		  spr.img = gEffectSpr
		  
		  let slotx = effectIdx%8
		  let sloty = Math.floor(effectIdx/8)
		  
	      spr.addFrame(slotx*64, sloty*64, 64, 64)

		  spr.setCSize(size, size)

				  
		  spr.begin()			
		  gEffectSprites.push(spr) 
		 	
          return spr  			
		  
}


function addEffectSpr_withoutMotion2(refX, refY, srcX , srcY , srcW, srcH, size, lifeT=1000){
	
	       
	      let spr = new sprite(refX, refY,  lifeT)
		  		  		  
		  spr.img = gEffectSpr
		  	  
	      spr.addFrame(srcX, srcY, srcW, srcH)

		  spr.setCSize(size, size)
	  
		  spr.begin()			
		  gEffectSprites.push(spr) 
		 	
          return spr  			
		  
}


function addHeartEffectSpr(refx, refy){
	
	let srcW = 21, srcH = 78
	let srcX = 491, srcY = 0
	
    let spr = new sprite(refx, refy,  2000)
	
	 spr.moveType = spr_move_none
					  
	  spr.img = gEffectSpr
		  
	  spr.addFrame(srcX, srcY, srcW, srcH)

	  spr.setCSize(50, gClientH)
  
	  spr.begin()			
	  gEffectSprites.push(spr) 
		
	  return spr  			

}



//===================
//
//

//app--->
function isNetworkConnected_JS(){
	
	if(gNetworkCheck==false){
		
		  return true 		
	}
		
   let isOnline =  navigator.onLine 	
	
	if(gIsDevice){
  
	   if(gIsAndroid){
	  
		  isOnline =  android.isNetworkConnected_JS() 

	   }
	   else {
		 
          		   
		   		   
	   }  	   
	   
   }
	
	
	return isOnline 	
}



function showIntersAd_JS(){
	
  console.log('showIntersAd_JS()')
  
  
	   if(gIsAndroid){
	  
		   android.onIntersAd_JS()
	   
	   }	   
	   else {
		   
		   try{
			   
		       webkit.messageHandlers.callbackJS.postMessage("showIntersAd_JS()")
			   
		   }catch(err){

			   console.log(err)
		   }
		   		   
				   
	   }

}


let gCountryStr = '--'

//device인지 미리 체그한 상태 
function getUserCountry_JS(){
	
	
    if(gIsAndroid){
			   
			  try{ 
					gCountryStr =    android.getUserCountry_JS()
					gPrint('cuntry' + gCountryStr)
					
			  }catch(err){
				  
			  }
			  
    }
	else { //ios 
			   			 
          webkit.messageHandlers.callbackJS.postMessage("getUserCountry_JS")
		  
    }
			   		   
}


//ios---->webView 
function ios_userCountry_byApp(country) {
	
   //Locale.current // en_KR (current)
   //Locale.current.regionCode // Optional("KR")
	
   gCountryStr = country
	
}


//호출전에 online체크로 변경 
function rewardVideo_JS(){
	
      if(gIsAndroid){
		   
			  //네이티브의  함수호출    
			   android.onRewardAd_JS()
			   //--------------------
			   //동영상이 끝난 후 heart개수 증가		
	   }
	   else {
	   
	          ios_showRewardAd_JS()
	   
	   }

	
}


let lastRewardAdT 

//app---->webView 
function appOnPostRewardAd(numHeart){
	
    console.log('appOnPostRewardAd()')

	gNumHeart+=numHeart
				
    lastRewardAdT = new Date().getTime()						
	window.localStorage.setItem('lastRewardAdT', lastRewardAdT.toString())	
			
	
	if(gAppState == appState_home){
		
	 	//home Menu를 보여줘야 합니다.	 	
		  showDivElmt('homemenuBG', true)
		  showDivElmt('homemenu', true)
		
	}
	else {

	  //현재 스테이지 다시도전 
	  // onRetryBtn()
		
	}
	
  //  playMusicByFname(gBGMusicFname)
		
		
}


//app---->webView 
function appOnPostIntersAd(){
	
    console.log('appOnPostIntersAd()')
	
	 if(gBegin_intersAd){
		 gBegin_intersAd = false 		 		 
			 
	    let bg = document.getElementById('screenBG')
	    bg.style.display = 'none'
		 
		 resumePlay()		 
		 
		 beginStage()		 
		 playMusicByFname(gBGMusicFname)
		 
	 }
	
}

//rewardAd가 로드가 되지 않은 경우 등
//동영상 광고 보지 않는 것처럼 처리
function appOnPostRewardAdFail(){
	
	gPrint('appOnPostRewardAdFail')
	
	if(gAppState == appState_home){
		
	 	//home Menu를 보여줘야 합니다.	 	
		  showDivElmt('homemenuBG', true)
		  showDivElmt('homemenu', true)
		
	}
	else {

	  //onHomeBtn()
		
	}
		
	
	
}


//webV --> add 
function hideBanner_JS( ){
	
	if(!gIsDevice){
		
		return 
	}
	
	
	if(gIsAndroid){
		
		android.hideBanner_JS( )
		
	}
	else {
				
		ios_hideBanner_JS() 
		
	}	
}

//=================
//webV --> add 
function showBanner_JS( ){

	if(!gIsDevice){
		
		return 
	}

    gPrint('showBanner_JS')
	
	if(gIsAndroid){
		
		android.showBanner_JS( )
		
	}
	else {
				
         ios_hideBanner_JS()
	}	
	
}




//=======================

 function webkitSendLogMsg(log){
    
    try {
        
        webkit.messageHandlers.iosListener.postMessage(log)
        
    }catch(err){
        
        alert(err)
        
    }
}

//===================


function getImage(rscIdx){

   switch(rscIdx){
	   
   case rscIdx_cat:
       return pet_spr

    case r_cat2:
       return pet_spr
	   
    case r_cat3:
       return pet_spr

  
  case rscIdx_pig :
      return pet_spr
   
   case  rscIdx_tiger:
      return tiger_img
	
   case  r_dog:
      return dog_img

	
   case r_rock_reflect:
      return rock_img   
	  
   case r_mon1:	  
   case r_mon2:
   case r_mon2_child:
   case r_mon3:
   case r_mon_bull:
    return monsterSpr
	
   case r_mon_eye:
   case r_mon_redcat:
    return monsterSpr2
	
	
  //-------------	
  case r_bullet:  
  case r_enemy_guard:  
  case r_cat_red:
   return bulletSpr
   
   
   case r_defense_ball:   
   return defenseSpr
   
   
   case r_diamond:
   return rock_img
	     
   default: 
   
      console.log('undefined rscIdx:--->' + rscIdx)   
   }
   
    return null   
}


function gPrint(str){
	
	if(gDebug){
		
	   console.log(str)
	}
}

//Math.floor(가장 정수로 내림된 수)
//ceil 
//round(반올림)
//toFixed
function getRandomVal(min, max){
 
  let range = max-min
 
 //random : 0~1[0 , 1 미포함]
  let result = min + (Math.random()*range)
  return result;
    
}

function getDistLineToPoint(lineA, lineB , point){
		
	let diffx = lineA.x - lineB.x 
	let diffy = lineA.y - lineB.y 
	
	let lineV = new Vec2(diffx ,diffy)	
	
	let normalV = lineV.normal()
	normalV.x = -1*normalV.x 
	normalV.y = -1*normalV.y 

	//(-y, x) + unit (CW)
		
    let v1 = {x: 0, y:0}
    v1.x = lineA.x - point.x
	v1.y = lineA.y - point.y
	
    let dist = v1.x*normalV.x + v1.y*normalV.y 
	
	if(dist < 0) {
		dist = -1*dist
	}
     
    return dist 	 
}

/*
try {
  await Promise.all([promise1, promise2, ..., promiseN]);
  console.log('Here, we know that all promises resolved');
} catch (e) {
  console.log('If any of the promises rejected, so will Promise.all');
}

===========
const myFirstPromise = new Promise((resolve, reject) => {
  // do something asynchronous which eventually calls either:
  //
  //   resolve(someValue)        // fulfilled
  // or
  //   reject("failure reason")  // rejected
});

=========
const promise1 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve('foo');
  }, 300);
});

promise1.then((value) => {
  console.log(value);
  // Expected output: "foo"
});

console.log(promise1);
// Expected output: [object Promise]

*/

function load_image_async(fname, oImgRef){
	
	return new Promise(function (resolve, reject){
		
		var img = new Image()
		
		img.src = fname
		img.onload = function (){
		
           // console.log(fname + '-->img onloaded')					
			resolve(img)			
		}
		
	   img.onerror = function (){

           console.log(fname + '-->img onerror')					
		   
	   }
				
	});
	
}


let imgLoadList
function check_rscLoaded( loadList){
	

	
}



function printPlayerState_d(){
	
	gPrint('IsFireReady: ' + gIsFireReady + ' IsAimState: ' + gIsAimState + ', IsValidAim: ' + gIsValidAim )
	
}



//필요할 때만 로딩하는 방식으로 변경 
//5개 
let prizePhotos = [] 

let prizePhotoInfos = {}
let prizePhotoFNames = ['photo-01', 'photo-02', 'photo-03', 'photo-04', 'photo-05', 'photo-06']

//idx =>  
function loadPrizePhoto(idx){	
		
		
	let key = idx.toString()	

    gPrint('loadPrizePhoto '+key)
	
	 let prizeImg = prizePhotoInfos[key]
	 if(prizeImg == null || prizeImg == undefined){

       load_image_async(prizePhotoFNames[idx]+'.jpg')
	   .then(function(img){
		   
		    prizePhotoInfos[key] = img 
			
		    onPostPrizePhotoLoad(img)
		   
	   })
	
	}
	else {
		
		   onPostPrizePhotoLoad(prizeImg)
	}	
	
}


function loadPrizePhoto(imgElmt, idx){	
		
	/*
	let key = idx.toString()	

    gPrint('loadPrizePhoto '+key)
	
	 let prizeImg = prizePhotoInfos[key]
	 if(prizeImg == null || prizeImg == undefined){

       imgElmt.src = prizePhotoFNames[idx]+'.jpg'
       imgElmt.onload = function(){
		   	   
	    onPostPrizePhotoLoad(img)
		   
	   }

	
	
	}
	else {
		
		   onPostPrizePhotoLoad(prizeImg)
	}	
	
	*/
	
}


function getClassicArtInfo(fname){
	
	let desc 
	
	for(let i=0; i < classicData.length; i++){
		
		let item = classicData[i]
		
		 if(item.fname == fname){
			 
			 return item.desc
		 }
	}
	
	
	return "---"
	
}



function regScoreToServer(score){
	
	console.log('regScoreToServer')
		
}

function isPetBall(ball){
	
	if(ball.rscIdx == r_pig || ball.rscIdx == r_tiger || 
	  ball.rscIdx == r_dog ||  ball.rscIdx == r_cat || 
	  ball.rscIdx == r_cat2 || ball.rscIdx == r_cat3 || 
	  ball.rscIdx == r_cat_red ){
		
             return true 		
	}
	
	return false 
}

function isRock(ball){
	
	if(ball.rscIdx == r_rock_reflect || ball.rscIdx == r_rock_reflect2 || ball.srcIdx == r_rock_reflect3
	|| ball.rscIdx == r_rock_01 || ball.rscIdx == r_rock_breakable 
	|| ball.rscIdx == r_rock_wrld_bound ){
		
		return true
	}

   return false 	
	
}

function isMonster(ball){

	if(ball.rscIdx == r_mon1 || ball.rscIdx == r_mon2 
	  || ball.rscIdx == r_mon2_child || ball.rscIdx == r_mon3
	  || ball.rscIdx == r_mon_bull 
	  || ball.rscIdx == r_mon_redcat){
		
		return true 
	}
	
	return false 
}

function isItem(ball){
	
	if(ball.rscIdx == r_item_bomb || 
	  ball.rscIdx == r_item_eye || 
	  ball.rscIdx == r_item_heart || 

	  ball.rscIdx == r_item_long || 
	  ball.rscIdx == r_item_photo ||
	  ball.rscIdx == r_item_diamond ||
	  ball.rscIdx == r_item_enemy_bullet_trigger ||
	  ball.rscIdx == r_item_double ||
	  ball.rscIdx == r_item_slow ) {
		  
		  return true 
		  
     }

       return false 
}


function getReflectWeight(rscIdx){
	
	let w = 1.0 
	if(rscIdx == r_rock_breakable){
		
		w = 0.9
	}
	else if(rscIdx == r_rock_reflect){
		
		w = 1.1
	}
	else if(rscIdx == r_rock_reflect2){
		
		w = 1.15
	}
	
   return w 		
}

function getFirstDefenseBall(){
	
     let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	     curBall = gBalls[i]
	   
		   if(curBall.isWaitForRemove == true){
			   
			   continue 
		   }
	   
		   if(curBall.rscIdx ==r_defense_ball ){
			   
			   return curBall		   
		   }		
	}
	
	return null 	
	
}



function stopDefenseBalls(){
	
	gPrint('stopDefenseBalls()')
	
	 let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	     curBall = gBalls[i]
	   
		   if(curBall.isWaitForRemove == true){
			   
			   continue 
		   }
	   
		   if(curBall.rscIdx ==r_defense_ball){
			   
			    curBall.setState(ballstate_anchored)
                curBall.setVelocity(0.0, 0.0)
               // curBall.isDebug = true
		   }		
	}
		
	
}


function getFirstMonsterBullet(){
	
	let ball 
    for(let i=0; i < gBalls.length; i++){
	
	     ball = gBalls[i]
	   
		   if(ball.isWaitForRemove == true){
			   
			   continue 
		   }
	   
		   if( ball.hasProp(ball_prop_monsterBullet) ){
			   
			   return ball 
		   }	
		   
	}
	
   return null 	
}


function slowDefenseBalls(){
	
	
	gPrint('stopDefenseBalls()')
	
	 let curBall 
    for(let i=0; i < gBalls.length; i++){
	
	     curBall = gBalls[i]
	   
		   if(curBall.isWaitForRemove == true){
			   
			   continue 
		   }
	   
		   if(curBall.rscIdx ==r_defense_ball){
			   
			    let nVel = getClampVec(curBall.velocity, gMinSpeed)
				curBall.velocity.x = nVel.x 	
				curBall.velocity.y = nVel.y 	
		   }		
	}
		
		
	
}


function getFirstPetBall(){
		
	let b 
    for(let i=0; i < gBalls.length; i++){
	
	     b = gBalls[i]
	   
		   if(b.isWaitForRemove == true){
			   
			   continue 
		   }		   
	   
		   if( isPetBall(b)  ){

              return b 			   
		   }		
	}
		
	return null 
	
}



function getFirstPaddleBulletTarget(slotX_px){

    let minx = slotX_px - 2.0
    let maxx = slotX_px + 2.0
	
	let b 
    for(let i=0; i < gBalls.length; i++){
	
	     b = gBalls[i]
	   
		   if(b.isWaitForRemove == true){
			   
			   continue 
		   }
		   
		   //bullet은 reflect3도 파괴 가능하므로 타겟 포함
		   if(b.rscIdx == r_rock_breakable || b.rscIdx == r_rock_float_anchor 
		   || b.rscIdx == r_rock_reflect || b.rscIdx == r_rock_reflect3){
			
			  if(b.pos.x >=minx && b.pos.x <= maxx){
				  
				     return b
			   }
			  
		   }		   
	   
	}
		
	return null 
	
}



function getRandomItem(){
	
	let rand = getRandomVal(1, 100)
	
	if(gNumHeart == 1){
		
		if( rand > 50){
			
			return r_item_gun
		}
		else {
				
		   return r_item_heart
		}
	}
	
	
	if(rand > 70){
	
        return r_item_heart	
	}
	else if(rand > 50){
		
		return r_item_gun
	}
	else if (rand >30){
	
         return r_item_double	
	}
	else {

        return r_item_long	
		
	}
	
	
	
}


/*
"kind" : 0 , 
# 0(math), 1(timeout)
"clearScore" : 10, 
#목표점수
"numDefRock" : 1, 
#맨위 나오는 돌  1줄 2줄 설정
"ballOrder" : [ 0, 0, 1],
#나오는 공 순서 0(pig), 1(cat), 2(cat2), 3(tiger)
"rock_r" : { x:2 , y:3} 
#반사하는 돌 배치 가로 2번째, 세로 3번째

"rock_r" : { "x":2 , "y":3} 
-->

*/

// rock_f =  0 ,	rock_h = 1, const rock_c =  2
function parseStageScript(lines){

    let oScript = ''
	let line 
	
	for(let idx=0; idx < lines.length; idx++){
	  
              line = lines[idx]	  
	
			  if(line.startsWith("#") ){
			   
				  continue
			   }
				   
			   
			   if(line.indexOf('rockArray begin') != -1){
				   
				   oScript += "\"rockArray\" : [ \n" 				   
	 		   }
			   else  if(line.indexOf('rockArray end') != -1){
				   
				   oScript += "\n]" 				   
	 		   }
			   else if(line.indexOf('ballOrders') != -1){
				   
				     let oLine = line.replace(/pig/g, '0');
				    oLine = oLine.replace(/tiger/g, '1' );		
		  		    oLine = oLine.replace(/cat/g,   '2');
				    oLine = oLine.replace(/cat2/g,  '3');
				   				   
				   oScript += oLine 
				      
			   }			   
			   else if( line.indexOf('rock_f') != -1){				
				//{rock_r ,  x:2 , y:3}				
				
						
				  let oLine = line.replace('rock_f', '\"type\" : 0');
				   oLine = oLine.replace('x:', '\"x\": ');
				   oLine = oLine.replace('y:', '\"y\": ');		
                
				   oScript += oLine 
				   
							
				}	
				else if(line.indexOf('rock_h') != -1){
					
				  let oLine = line.replace('rock_h', '\"type\" : 1 ');
				     oLine = oLine.replace('x:', '\"x\": ');
				   oLine = oLine.replace('y:', '\"y\": ');					  

                  
				   oScript += oLine 
				   
					
				}
				else if(line.indexOf('rock_c') != -1){
					
				   let oLine = line.replace('rock_c', '\"type\" : 2');
				   oLine = oLine.replace('x:', '\"x\": ');
				   oLine = oLine.replace('y:', '\"y\": ');		
					
					oScript += oLine 
				}
				else {
					
					
					oScript += line
				}

	}
	
    return oScript

}


/*
function collideWith_defenseBar(b){

      let pos = {x:0, y:0}

      pos.x +=  b.velocity.x*deltaT
				 this.pos.y +=  this.velocity.y*deltaT

   gDefenseBarX





}
*/

//image가 이미 로드되었는지 체크 

//array
let gCheckImgNames = [] 
let gCheckLoadInfos = [] 


function load_imageEx( imgElmt , fname){
	
	return new Promise(function (resolve){
		
		let needLoad = true 

		if(imgElmt.complete){
			
			let idx = imgElmt.src.indexOf(fname)
			if(idx == -1){
								
			}
			else {
				
				needLoad = false 
			}
			
		}
		
		if(needLoad) {
			
			 imgElmt.src = fname
			 imgElmt.onload = function(){
				 
				 resolve(imgElmt)
			 }
		}
		
	})
		
}









//let loadState = {
	
//ex) bg-03과 effect-sprite등 이미지가 모두 load되었는지 체크한 후 모두 load후 알려주기 

//fname, imgObj 

let gReload_rsc_array = [] 
//gReload_rsc_array.push({imgObj: bg_img , fname: "bg-03.png" }

function reload_rscAll(infoArray){
	
	gPrint('reload_rscAll()')
	
   let promise_array = [] 	
		
	for(let i=0; i < infoArray.length; i++){
		
		let info = infoArray[i]
		
	       promise_array.push( load_imageEx(info.imgObj, info.fname) )	
	}
	
	
	Promise.all(promise_array)
    .then(function(){

    gPrint('Promise all then() src: ' + bg_img.src)
	
   
  })
		
}






function onPost_RscAllLoaded(){
	
	gPrint('onPost_reloadRscAll()')	
	gIsRscAllLoaded = true 
	
}



function check_loaded_image(imgElmt, fname){
	
	gPrint('check_loaded_image')
	
	if(imgElmt.complete== true){
		
		console.log(fname +'src==>'+imgElmt.src)		
	}
	else {

		console.log('not complete')		
				
	}	
}


function getCountryFlagEmoji(dispName){
	
	if( dispName.includes("JP")  ){		
	
		return "🇯🇵"
	}
	else if(dispName.includes("KR") ){
		
		return "🇰🇷"
	}
	else if(dispName.includes("ES") ){
		
		//스페인
 		return "🇪🇸"		
	}
	else if(dispName.includes("US")){
		
		return "🇺🇸"
	}
	else if(dispName.includes("VN")){
		
		return "🇻🇳"
	}
				
	return "--"
}


function onPostStartPlay_JS(){

   gPrint('onPostStartPlay_JS')
   
   if(!gIsDevice){
     
	   return 
    }	   
								 
	   if(gIsAndroid){

		  try {
			 android.onStartPlay_JS()
		   }
		   catch {
			
		   }

		}
		else {

		   ios_onStartPlay_JS()

		}			
	 
}

//play이후 home으로 왔을 때
function onPostStartHome_JS(){
	
   gPrint('onPostStartHome_JS')
	
   if(!gIsDevice){
     
	   return 
   }	   
	
	if(gIsAndroid){

		  try {
			 android.onStartHome_JS()
		   }
		   catch {
			
		   }

		}
		else {

		   ios_onStartHome_JS()

		}			
}

/*

var imageNames = ["menuImage", "resetScoreButton", "instructionsButton", "playButton", "dialogPanel", "gamePlayImage", "exitButton", "timerPanel", "messengerPanel", "scoreBar", "yesButton", "noButton", "goButton"];
var imageFileNames = ["game_Menu", "reset_score_button", "instructions_button", "play_button", "dialog_panel", "game_play", "exit_button", "timer", "messenger_panel", "score_bar", "yes_button", "no_button", "go_button"];
var imageCollection = {};


=======[solution2]========
const imageCollection = loadImages(
    ["menuImage", "resetScoreButton", "instructionsButton", "playButton", "dialogPanel", "gamePlayImage", "exitButton", "timerPanel", "messengerPanel", "scoreBar", "yesButton", "noButton", "goButton"],
    ["game_Menu", "reset_score_button", "instructions_button", "play_button", "dialog_panel", "game_play", "exit_button", "timer", "messenger_panel", "score_bar", "yes_button", "no_button", "go_button"],
    drawGameMenu  // this is called when all images have loaded.
);

function loadImages(names, files, onAllLoaded) {
    var i = 0, numLoading = names.length;
    const onload = () => --numLoading === 0 && onAllLoaded();
    const images = {};
    while (i < names.length) {
        const img = images[names[i]] = new Image;
        img.src = files[i++] + ".png";
        img.onload = onload;
    }   
    return images;
}

=======[solution1]=========
var jarOfPromise = [];

    for(i = 0; i <= u; i++) {

        jarOfPromise.push(
            new Promise( (resolve, reject) => {
                var name = imageNames[i];
                imageCollection[name] = new Image();
                imageCollection[name].src = imageFileNames[i] + ".png";
                console.log(imageCollection[name]);
                imageCollection[name].addEventListener('load', function() {
                    resolve(true);
                });
            })
        )
    }


    Promise.all(jarOfPromise).then( result => {
        drawGameMenu();
    });
	
	===========================
	
	const images =
        { menu: { img:null , path:'images/Menu.png', status:'none' }
        , map : { img:null , path:'images/a6.png'  , status:'none' }
        };

function loadImage( ref ) {
  return new Promise(function (resolve) {

    console.log( ref.path );

    ref.img = new Image();

    ref.img.onload  =_=>{ ref.status='OK';  resolve() };
    ref.img.onerror =_=>{ ref.status='bad'; resolve() };

    ref.img.src = ref.path;
  });
}

Promise
  .all([ loadImage(images.menu), loadImage(images.map) ])
  .then(function(){
   
    console.log('menu:', images.menu.status);
    console.log('map :', images.map.status);
  })
	
	
	
	
	*/


/*
=================
//will activate instantly
img.onload = someFunction();

//same as above
img onload = function (argument) {//insert code}(argument_to_pass);

//these will work without problems
img.onload = someFunction; //this one should work but not 100% sure

img.onload = function () {//insert code}
*/
