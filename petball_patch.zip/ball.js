
class Vec2{
    constructor(x, y){
        this.x = x;
        this.y = y;
    }

    add(v){
        return new Vec2(this.x+v.x, this.y+v.y);
    }

    subtr(v){
        return new Vec2(this.x-v.x, this.y-v.y);
    }

    mag(){
        return Math.sqrt(this.x**2 + this.y**2);
    }

    mult(n){
        return new Vec2(this.x*n, this.y*n);
    }

    normal(){
        return new Vec2(-this.y, this.x).unit();
    }

    unit(){
        if(this.mag() === 0){
            return new Vec2(0,0);
        } else {
            return new Vec2(this.x/this.mag(), this.y/this.mag());
        }

/*		
	 static perpendicularCW(iV1){

               return new Vec2(iV1.y, -iV1.x);
	    }		
*/		
    }
	
	
	
 /*
    drawVec(start_x, start_y, n, color){
        ctx.beginPath();
        ctx.moveTo(start_x, start_y);
        ctx.lineTo(start_x + this.x * n, start_y + this.y * n);
        ctx.strokeStyle = color;
        ctx.stroke();
        ctx.closePath();
    }
  */  
    static dot(v1, v2){
        return v1.x*v2.x + v1.y*v2.y;
    }
	
}

//=================




//==================
function  vec2PerpendicularCW(iV1){

	   return new Vec2(iV1.y, -iV1.x);
}		

function vec2PerpendicularCCW(iV1){

	   return new Vec2(-iV1.y, iV1.x);
}		




/*
//collision resolution
//calculates the balls new velocity vectors after the collision
function coll_res_bb(b1, b2){
	//collision normal vector
    let normal = b1.pos.subtr(b2.pos).unit();
    //relative velocity vector
    let relVel = b1.vel.subtr(b2.vel);
    //separating velocity - relVel projected onto the collision normal vector
    let sepVel = Vector.dot(relVel, normal);
    //the projection value after the collision (multiplied by -1)
    let new_sepVel = -sepVel;
    //collision normal vector with the magnitude of the new_sepVel
    let sepVelVec = normal.mult(new_sepVel);

    //adding the separating velocity vector to the original vel. vector
    b1.vel = b1.vel.add(sepVelVec);
    //adding its opposite to the other balls original vel. vector
    b2.vel = b2.vel.add(sepVelVec.mult(-1));
}
*/

//서로의 velocity가 고려된 버전
function get_ball_responseV(A, B){
	
	let diffX = A.pos.x - B.pos.x 
	let diffY = A.pos.y - B.pos.y 
		 
    let length = Math.sqrt(diffX*diffX + diffY*diffY)		
    let normalV = {x: diffX/length, y: diffY/length}
	
    let speed = A.velocity.x*normalV.x + A.velocity.y*normalV.y
    speed = -speed  	

    let resV = {x: normalV.x*speed, y: normalV.y*speed} 	
	
	return resV 	
}

//A를 반대로 밀어내는  구하기 
//A와 B가 충돌(defenseBall --> r_rock_float_anchor)
function get_ball_responseV_d1(A, B){
	
	let diffX = A.pos.x - B.pos.x 
	let diffY = A.pos.y - B.pos.y 
		 
    let length = Math.sqrt(diffX*diffX + diffY*diffY)		
    let normalV = {x: diffX/length, y: diffY/length}

    //default speed: 0.2 	
	let refLen = A.radius + B.radius + 1
	
	let safePosX = B.pos.x + refLen*normalV.x
	let safePosY = B.pos.y + refLen*normalV.y
	
	let safePos = {x: safePosX , y: safePosY}
		
		
    let resp_info= {respV: normalV, rePos: safePos} 	

	
	return resp_info 	
}


//A의 반사벡터 구하기 
function get_ball_responseV_d2(A, B){
	
	
	
	let diffX = A.pos.x - B.pos.x 
	let diffY = A.pos.y - B.pos.y 
		 
    let length = Math.sqrt(diffX*diffX + diffY*diffY)		
    let normalV = {x: diffX/length, y: diffY/length}

    //default speed: 0.2 	
	let refLen = A.radius + B.radius + 0.1
	
	let safePosX = B.pos.x + refLen*normalV.x
	let safePosY = B.pos.y + refLen*normalV.y
	
	let safePos = {x: safePosX , y: safePosY}
		
    let resp_info= {x: normalV.x, y: normalV.y, rePos: safePos} 	
	
	return resp_info 	
}


//A의 평면기준 정반사벡터 구하기 
//A(moveState)
function get_reflectV_normal_vh(A, B, refSpeed){
			
	let diffX = A.pos.x - B.pos.x 
	let diffY = A.pos.y - B.pos.y 

    let diffX_abs = diffX 	
	
	if(diffX_abs < 0){
		
		diffX_abs = -1*diffX 
	}
	
	let diffY_abs = diffY
 
    if(diffY < 0){
		
		diffY_abs = -1*diffY 
	}
    
		 
    let length = Math.sqrt(diffX*diffX + diffY*diffY)		

    let reflectV = {x:0 , y: 0}
		
    //major normal벡터구하기
	if(diffX_abs > diffY_abs){
			   
	   if(Math.abs(A.velocity.x) <= 0.05){
		   		   		   
		   //밀어내는 벡터로 변경
			 reflectV.x = (diffX/length)*refSpeed  
			 reflectV.y = (diffY/length)*refSpeed  
	   
		   		   
	   }else {
	   
		   reflectV.x = -1*A.velocity.x 
		   reflectV.y = A.velocity.y 

	   }
	   
	  // 	gPrint('normal: vertical:' + A.velocity.x ) 
		
	}
	else if(diffX_abs < diffY_abs){
		
		
		
	   reflectV.x = A.velocity.x 
	   reflectV.y = -1*A.velocity.y 		
	   
	   
	   
	 //  	gPrint('normal: horizontal')
	   
	}
	else {
	
    //반대방향으로 	
	
		//gPrint('get_reflectV_normal_vh()--->reflectV not defined')
		
		
	}


	
	return reflectV
}


//------------------------------
//manage dist-joint 
//-----------------------------

class ball{
	
	constructor(rscIdx, radius){
		
		
     	//------------
		this.rscIdx = rscIdx
		//-----------
		
		this.pos = {x: 0, y: 0}
		this.radius = radius
 				
        this.img = new Image()		
		this.state = 0
		
		this.velocity = {x:0, y:-0.5}
		
		this.angleR = 0
		this.angleSpeed = 0.1
		
		this.link_idx = -1
		this.link_ball_id = -1
		
		this.id = 0 
		
		//for회전 중심 
	    this.circleCenter = {x:0, y: 0}
		
		this.isWaitForRemove = false 
		
		this.isCheckMatchedBall = false  
		
		this.anchor = {x:0, y:0}
		this.lastAnchor = {x:0, y:0}
		//---------
		this.isAnchored = false 
		
		this.acc = {x:0, y:0};
		
		//자신을 끌어당기는 ball 
		this.drawer_id = 0		
		
		this.prop = 0
		
		this.iSpriteIdx = 0 
		
		this.frameLastT = 0
		
	    this.movePatternIdx = 1 
		this.movePatternState = 0
		
		this.circleMoveAngle = 0
		
        //for monster		
		this.hp = 10
		this.maxhp = 10

		this.power = 1
		this.bounceCount = 0
		
        //하나의 이미지에 여러 ball그림이 있는 경우  		
		this.useSprite = false 
		
	    this.sprFrames = [] 
		this.numSprFrame = 0 
		
		this.useCustomSprIdx = false 
 				
        this.level = 1
	   
	  //  this.motion  = null 

		this.ai = null 
			
		this.moveMin = 0
		this.moveMax = 100 
		
	   this.customRadius = 0 
		
		
		this.isDebug = false 
		
		//rock등이 충돌된 경우 
		this.isHit = false 
	    this.hitEventT = 0
		
       ////미리 생성만 된 경우 		
		//this.isWaitForActive =  false 
		
		//0(infinite)
		this.lifeT = 0
		this.elapsT = 0
		
		this.wakeT = 0 //0(외부에서 wake를 해제)
		this.stateAfterWake = ballstate_anchored
		
		this.effectSpr = null
		
		
		this.post_rscIdx = -1
		//this.groupSlotIdx = -1
		
		this.userPos = {x: 0, y: 0}		
		this.userVal  = 0 //회전운동 반지름 등, centerToNomal step등
		this.userT = 0
		
		this.circleAngleSpeed = 2
		
		//----------------
	//	this.is = 0
		
		this.cmdList = []
		
		//pattern_dst_idx
		this.pattern_dst_Idx = 0
		
		this.usePatternDstPos = false 
		
		this.patternRefPos = {x: 0, y: 0}
		
		//----------
		this.refBall_id = 0 
		this.offsetPos = {x:0, y:0} //fromRefBall 
		//---------
		
		this.movePatternGroupIdx = 0
		
		this.patternVelocity = {x:0, y:0}
				
		this.restoreDelta = {x: 0, y: 0}
		this.restoreDist = {x: 0, y: 0}
		
		this.restoreUpdateCount = 0
		
		this.floatAnchorId = -1 //(no
		
		this.scale = 1.0
		
		
		this.pool_idx = -1
		
		
		//다이아몬드가 3번 hit시 rock으로 변환
		this.hitCount = 0
			
			
		this.dstPos = {x:0, y:0}
        this.isArriveDstPos = false 			
		
		this.userEventT = 0
		this.isFocus = false 

        this.normalKind = normal_unknown			
	}
	
	reset(){
				
		//------------
		this.rscIdx = r_rock_01
		//-----------		
		this.pos = {x: 0, y: 0}
		this.radius = rock_radius
 				
		this.state = 0
		
		this.velocity = {x:0, y:-0.5}
		
		this.angleR = 0
		this.angleSpeed = 0.1
		
		this.link_idx = -1
		this.link_ball_id = -1
		
		this.id = 0 
		
		//for회전 중심 
	    this.circleCenter = {x:0, y: 0}
		
		this.isWaitForRemove = false 
		
		this.isCheckMatchedBall = false  
		
		this.anchor = {x:0, y:0}
		this.lastAnchor = {x:0, y:0}
		//---------
		this.isAnchored = false 
		
		this.acc = {x:0, y:0};
		
		//자신을 끌어당기는 ball 
		this.drawer_id = 0		
		
		this.prop = 0
		
		this.iSpriteIdx = 0 
		
		this.frameLastT = 0
		
	    this.movePatternIdx = 1 
		this.movePatternState = 0
		
		this.circleMoveAngle = 0
		
        //for monster		
		this.hp = 10
		this.maxhp = 10

		this.power = 1
		this.bounceCount = 0
		
        //하나의 이미지에 여러 ball그림이 있는 경우  		
		this.useSprite = false 
		
	    this.sprFrames = [] 
		this.numSprFrame = 0 
		
		this.useCustomSprIdx = false 
 				
        this.level = 1
	   
	  //  this.motion  = null 

		this.ai = null 
			
		this.moveMin = 0
		this.moveMax = 100 
		
	   this.customRadius = 0 
		
		
		this.isDebug = false 
		
		//rock등이 충돌된 경우 
		this.isHit = false 
	    this.hitEventT = 0
		
       ////미리 생성만 된 경우 		
		//this.isWaitForActive =  false 
		
		//0(infinite)
		this.lifeT = 0
		this.elapsT = 0
		
		this.wakeT = 0 //0(외부에서 wake를 해제)
		this.stateAfterWake = ballstate_anchored
		
		this.effectSpr = null
		
		
		this.post_rscIdx = -1
		//this.groupSlotIdx = -1
		
		this.userPos = {x: 0, y: 0}		
		this.userVal  = 0 //회전운동 반지름 등, centerToNomal step등
		this.userT = 0
		
		this.circleAngleSpeed = 2
		
		//----------------
		//this.is = 0
		
		this.cmdList = []
		
		//pattern_dst_idx
		this.pattern_dst_Idx = 0
		
		this.usePatternDstPos = false 
		
		this.patternRefPos = {x: 0, y: 0}
		
		//----------
		this.refBall_id = 0 
		this.offsetPos = {x:0, y:0} //fromRefBall 
		//---------
		
		this.movePatternGroupIdx = 0
		
		this.patternVelocity = {x:0, y:0}
				
		this.restoreDelta = {x: 0, y: 0}
		this.restoreDist = {x: 0, y: 0}
		
		this.restoreUpdateCount = 0
		
		this.floatAnchorId = -1 //(no
		
		this.scale = 1.0
		
			
		//다이아몬드가 3번 hit시 rock으로 변환
		this.hitCount = 0
			
			
		this.dstPos = {x:0, y:0}
        this.isArriveDstPos = false 			
		
		this.userEventT = 0
		this.isFocus = false 

        this.normalKind = normal_unknown			
		
		
		
	}
	
	setMoveBoundX(min, max){
		
		this.moveMin = min 
		this.moveMax = max 
	}
	
	setMoveBoundY(min, max){
		
		this.moveMin = min 
		this.moveMax = max 
	}	
	
		
	resetSprFrame(){

       this.useSprite = false 
	   this.numSprFrame = 0 
	   this.sprFrames = [] 
	   
	}		
		
	addSprFrame(x,y, w,h){
		
		this.useSprite = true 		
		let frame = {x:x, y:y, w:w, h: h}
		this.sprFrames.push( frame )
		
		this.numSprFrame++ 
	}

  //==============
   setAct(actIdx){
	   
	    if(actIdx == act_idle){
		   
		   this.iSpriteIdx = 0
		   
	   }	   
	   else  if(actIdx == act_attack){
		   
		   this.iSpriteIdx = 1
 
	   }
	   else  if(actIdx == act_damage){
		 
          if(this.ai!=null){
			  
			  this.ai.setState(actIdx)
		  }			  
		  
		   
	   }
	   else if(actIdx == act_dead){
		   
		    if(this.ai!=null){
								
			}
		   
	   }
	   
	   
   }
   //============

   moveTo(x, y){

    this.pos.x += x 
    this.pos.y += y
	
	this.anchor.x +=x 
	this.anchor.y +=y 
	
	this.circleCenter.x +=x 	
	this.circleCenter.y +=y 
	
   }	   
	
	
	setVelocity(vx, vy){
		
		this.velocity = {x: vx, y: vy} 
	}
	
	setVelocity2(vx, vy){
		
		this.velocity2 = {x: vx, y: vy} 
	}
	
	addVelocity(vx, vy){
		
		this.velocity.x += vx
        this.velocity.y += vy 
	}
	
	
	setPos(x, y){
		
		this.pos.x = x;
		this.pos.y = y;
	}
	
	setAnchor(x,y){
		
		this.anchor.x = x;
		this.anchor.y = y;
		
	}
	
	setLastAnchor(x, y){
		
		this.lastAnchor.x = x 
		this.lastAnchor.y = y
	}
	
	setCircleCenter(x, y){
		
		this.circleCenter.x = x 
		this.circleCenter.y = y 
		
	}
	
	addProp(iProp){
		
		this.prop |= iProp 
		
	}
	
	removeProp(iProp){
		
		this.prop &=~iProp 
	}
	
	resetProp() {
		
		this.prop = 0 
	}
	

	hasProp(iProp){
		
		if((this.prop&iProp) != 0){
			
			return true;
		}		
		return false;
	}
	
   isMyLinkBall(id){
				
		let res = isDistJoint(this.id, id)
		
		return res
		
	}
	

    isValidDrawBall(test_id){

		let refX =  this.pos.x;
		let refY =  this.pos.y;	
		
		let testBall = getBall(test_id)
		
		 if(testBall == null){
			
			  return false 
		 }		
		
   }	   
	
//=========================
//
//=========================	
 update(deltaT){
		
		this.isCheckMatchedBall = false  					


         if(this.ai != null || this.ai != undefined){
			 
			 if(this.hasProp(ball_prop_waitForWake) ==false 
			 && this.state != ballstate_fallingDown 
			 && this.isWaitForRemove ==false ) {
				 			 
		         this.ai.update(deltaT)
			 }
			 
		  }	
		  
		  
		 if(this.lifeT > 0){

     	       this.elapsT += deltaT 
	
	          if(this.elapsT > this.lifeT){
				  
				  gPrint('elapsT ' + this.elapsT)

                   this.isWaitForRemove = true 		
				   
                   return 				   

			   }				  
			   			   
		 }			 
		 
       //======================
	   //enemy_bullet(= enemy_guard)
		if( this.rscIdx == r_enemy_guard ){
			
			 if(this.hasProp(ball_prop_monsterBullet) ){
								 
				 procMonsterBullet(this, deltaT)
				 
				 return 
			 }				 
			
			if( this.state == ballstate_move || this.state == ballstate_move_toDst || this.state == ballstate_move_pattern){
				
		 		   proc_enemyGurad(this, deltaT)					
				   return 	
			}

		}
		//====================================

         if(this.isFocus){
			 		
			if(gStageElapsT >= this.userEventT + 200){

				   this.isFocus = false 
				   
				   if(isPetBall(this) == false ){
					   
					    this.radius = rock_radius
				   }
				   
			}				
		
		 }
		 
		
	  
//=================
         if(this.hasProp(ball_prop_waitForWake) ){
			 
			 
			 if(this.wakeT >0) {	 //0인 경우는 외부에서 wake 			
					  
                 if(gStageElapsT >= this.wakeT ){
					 				
 				  let spr = addEffectSpr(this.pos.x, this.pos.y, 1 , 100, 400)	 	 

				  spr.blendType = spr_blend_sourceOver
				  spr.isLowLayer = true 
				 				
                   this.removeProp(ball_prop_waitForWake)
				  
				}
			 }	

			 
		 }
//================		 
		 
		 
		 		 
		 if(this.isDebug){
			 
	          gPrint( this.id + '-->state' + this.state)
              this.printPosition()			  
		 }
		 

    	  if(this.hasProp(ball_prop_restore_toAnchor) ){
				 
				 
				 this.updateRestoreToAnchor2(deltaT)
	      }
		 
  		 		 
				 
				 
		 
		 if(this.rscIdx == r_rock_01 ||this.rscIdx ==r_rock_wrld_bound 
		    ||this.rscIdx== r_rock_reflect || this.rscIdx== r_rock_reflect2 
			|| this.rscIdx== r_rock_reflect3|| this.rscIdx== r_rock_reflect4
			|| this.rscIdx== r_rock_reflect_invincible) {
			 
			 if(this.isHit){
				 
				 if(gAppCurT >= this.hitEventT +  300){
					 
					 this.isHit = false 
					 this.iSpriteIdx = 0
				 }
			 }			 
			 
		 }
		 
		 
	   if(this.state == ballstate_anchored){
			 
		
			if(this.rscIdx == r_defense_ball){
				
				this.pos.y = gPlayerRefY - 30 
				
				
			}
		
				 	 
    	}
        else if(this.state == ballstate_move){
			
			
				let acc = 0.0	
				
				
				let minX = gPlayableSize.x + this.radius 
				let maxX = (gClientW -  gPlayableSize.x ) - this.radius 
				
  		         this.pos.x +=  this.velocity.x*deltaT             
				 this.pos.y +=  this.velocity.y*deltaT
				 
				 let deltaY = this.velocity.y*deltaT
				 
				  if(this.isDebug){
					 
					 
				//	 gPrint( this.id + '-->state' + this.state + 'deltaY: ' + deltaY)
					 this.printPosition()
					// this.printVelocity()
					 
				 }
			
			
			     if(this.rscIdx == r_defense_ball){
			 
						 
						 if( this.effectSpr !=null ){
							 
							 this.effectSpr.setPos(this.pos.x, this.pos.y)
						 }			

				 }
				 
				 
								 
				 
                 if( this.hasProp(ball_prop_not_collision_wall) ){
					                       
					   if(this.pos.x < 0 || this.pos.x > gClientW ){

							  this.isWaitForRemove = true 
							  return 
						 }
						 
	                    if(this.pos.y < 0 || this.pos.y > gClientH ){

							  this.isWaitForRemove = true 
							  return 
							  
						 }

				 }
				else {
					//벽과 충돌처리 
					

						 if(this.pos.x <= minX){
							 
							    this.pos.x = minX
								
								 this.velocity.x = -1.0*this.velocity.x
								

                                 let speed = getVecLength(this.velocity)								 								 								 								 
								 let angle = getAngle(1.0, 0, this.velocity.x, this.velocity.y)
								 
								 
								 if(angle < 20){
								     
				 					    gPrint('------------angle too small  ' )					
									                                   				 									 
		 							    let dir = {x:0, y:0}
                                        let refV = {x:1.0, y:0.0}
									 
										 if(this.velocity.y > 0){

											dir = rotateVec(1.0, 0 , 30)			
											 
										 }
										 else {
											 
										 	dir = rotateVec(1.0, 0,  -30)			
											 
										 }
								      
									  
									     this.velocity.x = dir.x*speed*1.02
									     this.velocity.y = dir.y*speed*1.02										 
								   
								 }
								 else {
									 
									 
									  this.velocity.x = this.velocity.x*1.02
									  this.velocity.y = this.velocity.y*1.02
									 									 
								 }
								 
								 //=========================
								 
								 let rVelocity =  getClampVec(this.velocity, gMaxSpeed)
								 
								 this.velocity.x = rVelocity.x 
								 this.velocity.y = rVelocity.y 
								 
								 //printVec('vel' , this.velocity)
								 //==========================
								 
								 
								 this.bounceCount++								 
								 

							//	 playSoundNote(sound_note_re);
								 
								 
								 
								 this.power +=0.3
								 if(this.power >= 2.0){
									 
									 this.power = 2.0
								 }
								 
								 
								 if(this.rscIdx == r_enemy_bullet){
									 
									 this.setState(ballstate_anchored)
									 
								 }
								 
								 return
								 
						 }
						 else if(this.pos.x >= maxX){

							    this.pos.x = maxX
								
						        this.velocity.x = -1.0*this.velocity.x				
							
                                 let len = getVecLength(this.velocity)
   
								//보정하기 
							    let angle = getAngle(-1.0, 0, this.velocity.x, this.velocity.y)
                        		//gPrint(this.id + '--  hitWall(maxX) angle: ' + angle )
								// printVec('velocity' , this.velocity)	
						   	
								 if(angle < 20){
								     
				 					    gPrint('------------angle too small  ' )					
									                                   				 									 
		 							    let nVel = {x:0, y:0}
                                        let refV = {x:1.0, y:0.0}
									 
										 if(this.velocity.y > 0){
											 //위에서 아래로 가는 경우 
											 
											nVel = rotateVec(1.0, 0 , 360-30)			
											 
										 }
										 else {
											 
										 	nVel = rotateVec(1.0, 0,  +30)			
											 
										 }
								      
									     //기본 speed : 0.2
									  
									     let speed = len*1.02
         							     this.velocity.x = -1*nVel.x*speed
									     this.velocity.y = -1*nVel.y*speed
										 
									   
									   printVec('newVel' , this.velocity)
								   
								 }
								 else {
									 
									 
									  this.velocity.x = this.velocity.x*1.02
									  this.velocity.y = this.velocity.y*1.02
									 									 
								 }
								 
					     	    let rVelocity =  getClampVec(this.velocity, gMaxSpeed)
								 
								 this.velocity.x = rVelocity.x 
								 this.velocity.y = rVelocity.y 
								 
								// printVec('vel' , this.velocity)
							
							

								 this.power +=0.3
								 if(this.power >= 2.0){
									 
									 this.power = 2.0
								 }

																							 
							    this.bounceCount++
								
																
							//	playSoundNote(sound_note_do);
								
								
								 if(this.rscIdx == r_enemy_bullet){
									 
									 this.setState(ballstate_anchored)
									 
								 }								 
								
								return
						 }
		
 		                  let maxY = gClientH -this.radius

						  //fallingdown을 고려해야함
					      let worldMinY = gCeilRefY + this.radius  //gPlayableSize.y + this.radius 
						 
					      
						  if(this.pos.y >= maxY) {
							 
						  	     /*
								 if(this.hasProp(ball_prop_collide_ground)){
									 
									 this.pos.y = maxY 
									 this.velocity.y = -1.0*this.velocity.y 
																									 
								 }
								 */
								 
							 	  //console.log('defenseB is under paddle')
								  //추가
			                      //this.isWaitForRemove = true	   
								  
								  return 
			  
						 }
						 else if(this.pos.y <= worldMinY){
									
								 this.pos.y = worldMinY
								 this.velocity.y = -1.0*this.velocity.y 
					 
								 //let angle = getAngle( 0, 1.0, this.velocity.x, this.velocity.y)									 
								 //gPrint('topWall reflectAngle' + angle)
								 
								  playSoundNote(sound_note_mi) 
																
							     return 
						 }
						 					
			 	}	
				
			 
 		  	      if(this.angleSpeed > 0){
					
					   this.angleR += this.angleSpeed 
				  }
					 
				 
				 if( this.hasProp(ball_prop_not_gravity) ){

				     
				 }
				 else {
					 
					  this.velocity.y += worldGravity*deltaT
					 
				 }
                //=====end collide with wall ==============				
                			   
			    
                 //======Ball과 충돌처리========								
				 let collision_array = resolveCollision(this)
				 				 				
				  if(collision_array.length	> 0){																  
					  this.isCheckMatchedBall = true 							
					  
                     gPrint('collsion array length : ' + collision_array.length)					  
					  
				  }
				  
				  
				  
				  //=================================
   	  		     for(let idx=0; idx < collision_array.length; idx++){
							
						let info = collision_array[idx]
						let peerBall = info.ball
						
						
						if(isItem(this)){
							
							//아이템은 별도의 충돌처리 없음
							return
						}
					

						if(this.rscIdx == r_defense_ball) {
							
			 				   if(peerBall.hasProp(ball_prop_monster) ){
								
								  this.proc_defenseBall_collideWith_monster(peerBall, info)								
								 
								 }else {
								
									//true(--->defenseBall), item, rock 등
									proc_defenseBall_collideWith_ball(this, peerBall, info)
								}
								
                             return
					    }												
                        
						if(this.hasProp(ball_prop_enemy_bullet)  ){
							//자신이 enemy 총알인 경우							
	                        this.proc_enemy_bullet_collideWith_petBall(peerBall)
							
							return 
                     
					    }						
						else if(this.rscIdx == r_enemy_bullet ){
							
							if( peerBall.hasProp(ball_prop_monster) ){


                                 console.log('monster coll with enemy bullet')
							}								
							
						
						}						
						else if(peerBall.rscIdx == r_rock_01 || 
						peerBall.rscIdx == r_rock_reflect || 
	                	peerBall.rscIdx == r_rock_reflect2 ||
	                	peerBall.rscIdx == r_rock_reflect3 ||						
						peerBall.rscIdx == r_rock_hole ||  
						peerBall.rscIdx == r_rock_breakable|| 
						peerBall.rscIdx == r_rock_float_anchor || 
						peerBall.rscIdx == r_rock_wrld_bound){

						     this.proc_collideWith_rock(peerBall, info)
							 
							 return 
							 							 							 							 
						 }					
						 else if(peerBall.hasProp(ball_prop_monster)){
							 
							 let monBall =  peerBall

                          	console.log('petBall--->colli MonBall')
                             this.proc_collideWith_monster(monBall)
							 
							 
							 monBall.addProp(ball_prop_restore_toAnchor)
							 monBall.setVelocity2(this.velocity.x, this.velocity.y)	
							 
							 monBall.pos.x += this.velocity.x*deltaT
							 monBall.pos.y += this.velocity.y*deltaT
						    
							 monBall.restoreDist.x = monBall.anchor.x - monBall.pos.x 
					 	     monBall.restoreDist.y = monBall.anchor.y - monBall.pos.y 
						     monBall.restoreUpdateCount = 0 

							 
						 }
						 else if(peerBall.hasProp(ball_prop_enemy_bullet) ){								   
							// petBall collideWidth enemyBullet 경우 	   
							  
							    gPrint('petBall collide enemybullet')
							  
								proc_petBall_collide_enemyGuard(this, peerBall)
								
					     }
						 else if( isItem(peerBall)  ){
							 
														
 							gPrint('peerB item found')
																												
								//true(isRemove)						   
							   this.collideWith_item(peerBall, true)
							 //  force_post_ball_interact()							   							   
																
							   return
						 }						 
						 else {
							 
							 
														 
					 		   //petBall과 충돌 							 
							   console.log('petBall' + this.id + ' rIdx: ' + this.rscIdx + '.collision with petBall '  + peerBall.id + 'rIdx' + peerBall.rscIdx)
							   
							
								if(this.rscIdx  ==  info.ball.rscIdx){
									
							         regMatchBall_id(this.id, info.ball.id)		
                                    									
									 playSoundEffect(sound_hit_03, 0.2)	
								}
								else {
									//다른 petBall과 
							       								
									playSoundEffect(sound_cat_02, 0.2)
								}
								
								
				
							   //===========================
							   //상대 petball이 아직 move상태인 경우
							   if(peerBall.state == ballstate_move){
								   
								   peerBall.setState(ballstate_fallingDown)
                                   
								   this.setState(ballstate_fallingDown)

								  
								   return 
							   }
							   //=========================
								
															
															
								 let refDist = this.radius + info.ball.radius 
								
								 regDistJoint( peerBall.id, this.id, refDist)
								 gPrint('regDistJoint in ball. update')

                                //----------------------------
								if(peerBall.hasProp(ball_prop_updateAnchor)){
									
									    this.addProp(ball_prop_updateAnchor)
									
									
										this.refBall_id = peerBall.id
										this.offsetPos.x = this.pos.x - peerBall.anchor.x 
										this.offsetPos.y = this.pos.y - peerBall.anchor.y 
										
								}
																
								//----------------------
								if(peerBall.floatAnchorId != -1){
									
									this.floatAnchorId = peerBall.floatAnchorId
								}			
								//----------------------
								
								
								 
								 if(peerBall.state == ballstate_anchored){
															
										if(peerBall.hasProp(ball_prop_updateAnchor) ){
											  
											  //움직이는 rock과 연결된 ball과 충돌한 경우
											  this.addProp(ball_prop_not_draw)
											  											  											   
									           gPrint(peerBall.id + '==>addProp(ball_prop_restoreToAnchor)') 
											   peerBall.setAnchor(peerBall.pos.x, peerBall.pos.y)											  
											  
											    peerBall.addProp(ball_prop_restore_toAnchor)
											  	peerBall.setVelocity(this.velocity.x, this.velocity.y)	
											    												
												let deltaX = this.velocity.x*20
                                                let deltaY = this.velocity.y*20 		
												
												gPrint(peerBall.id +  '->collision delta: ' + deltaX + ', '+deltaY)
												
												peerBall.pos.x += deltaX
												peerBall.pos.y += deltaY
												
												peerBall.restoreDist.x = peerBall.anchor.x - peerBall.pos.x 
			                   	       	        peerBall.restoreDist.y = peerBall.anchor.y - peerBall.pos.y 
											    peerBall.restoreUpdateCount = 0
												
																						   
										}
										else {
											
											        gPrint(peerBall.id + '.anchorPos: ' + peerBall.pos.x + ',' + peerBall.pos.y) 
													peerBall.setLastAnchor(peerBall.pos.x , peerBall.pos.y)
													peerBall.setVelocity(this.velocity.x, this.velocity.y)	
									              //  peerBall.setState(ballstate_move_byExtForce)
													
												   let deltaX = this.velocity.x*20
                                                   let deltaY = this.velocity.y*20 		
												
											     	//gPrint(peerBall.id +  '->collision delta: ' + deltaX + ', '+deltaY)
													
													peerBall.pos.x += deltaX
													peerBall.pos.y += deltaY
													
									 		        peerBall.addProp(ball_prop_restore_toAnchor)
												
													peerBall.restoreDist.x = peerBall.anchor.x - peerBall.pos.x 
													peerBall.restoreDist.y = peerBall.anchor.y - peerBall.pos.y 
													peerBall.restoreUpdateCount = 0
																										
										 }	
	
								 }
								
                            
																 
								 //pos는 object이므로 참조값을 사용
								 //(주의! pos가 바뀌면 anchor도같이 바뀜)							 
								 this.anchor.x = this.pos.x 
								 this.anchor.y = this.pos.y
							 
		 					     //자기자신도 반사벡터 적용 													
								 this.setVelocity(info.resV.x, info.resV.y)
								 //interactive하지 않고 시각적으로만 밀렸다가 다시 anchor로 돌아오기 								  
								 this.setState(ballstate_anchored)
								 
								 this.pos.x += this.velocity.x + getRandomVal(1, 2)
								 this.pos.y += this.velocity.y + getRandomVal(1.0, 1.5)
                                 this.addProp(ball_prop_restore_toAnchor)
								 
								 
								    if(gPrintDebugInfo){

										gPrint('begin----getNearestDrawer()')										
										console.time('getNearestDrawer()')								  
                                       										
								   }

								    //자신을 draw할 수 있는 ball찾기
								   let  drawer = getNearestDrawer(this)
		
						            if(gPrintDebugInfo){
										
                                  	    gPrint('end----getNearestDrawer()')
										console.timeEnd('getNearestDrawer()')								   
								   }
		
                                      
								
								 if(drawer != null){
									
									//attract , pull 			
									this.addProp(ball_prop_waitFor_drawer)		
									drawer.addProp(ball_prop_drawer)
									//drawer처리가 끝날 때 까지 기다렸린 후 post_ball_interact 이벤트를 생성 	

									procDrawerBall(drawer, this) 
								  
									 
								 }
								 else {
																			 
								 //draw결과 상관없이 match처리를 합니다.
								 // let event = new CustomEvent("post_ball_interact", {detail:{id:this.id} })
								 // document.dispatchEvent(event)							
								 
								 }
									 
																		 									 
						 }//else 						 
						 
									
				      } //for(let idx=0; idx < collision_array.length; idx++).... collision
					  					  
 							
		} 		
		//ballstate_move
		else {
		
          this.updateMove2(deltaT)		
			
		}
		
		
				
				
				
		
	} //update 
	

   //=============================	
	collideWith_item(itemB, isRemove=true){
		
		gPrint('begin----petBall_collide_item')

		if(isRemove){

         	    this.setState(ballstate_fallingDown)		
		}
		//----------------
		procItem(itemB)
		//---------------
		
        itemB.isWaitForRemove = true 		
		
		//== post process=========================		
		if(itemB.rscIdx != r_item_bomb){

			playSoundEffect(sound_good)			
		}
		
		
		if(itemB.rscIdx == r_item_bomb){
						
	       let size = gClientW*0.4						
		   let spr = addEffectSpr(itemB.pos.x , itemB.pos.y, 1, size, 400)
		   spr.sizeSpeedLevel = 1
		   
		   playSoundEffect(sound_bomb)
								
		} //r_item_bomb		
		else if(itemB.rscIdx == r_item_eye){
									
			let spr = addEffectTextSpr(itemB.pos.x, itemB.pos.y, '+Eye!')			
			   spr.colorStr = '#fff'
			   spr.motion.velX = 0
			   spr.motion.velY = 0
			   spr.motion.angleSpeed = 0    
			   spr.motion.useGravity = false 
					
		}
		else if(itemB.rscIdx == r_item_smaller){
						
			//addEffectTextSpr(itemB.pos.x, itemB.pos.y, '+Smaller Ball!')			
		}
		else if(itemB.rscIdx == r_item_photo){
						
		  // addGameCmd('get_prizephoto' , getNewPrizePhotoIdx())
		    addGameCmd('get_prizephoto' , null)
		
		}
        else if(itemB.rscIdx == r_item_heart){

           gNumHeart += 1		       

		}else if(itemB.rscIdx == r_item_slow){

			this.velocity.x *=0.8
			this.velocity.y *=0.8

		}else if(itemB.rscIdx == r_item_double){

  
			let xp = itemB.pos.x, yp = itemB.pos.y

            addGameCmd('item_double', {x: xp, y: yp}  )
		}			


/*		
		//속도 줄이기
		this.velocity.x *=0.9
		this.velocity.y *=0.9
*/

	gPrint('end----petBall_collide_item')
		
	}
	//petBall_collide_item
	
	
/*
   updateRestoreToAnchor(deltaT){
	   	   	   
        this.pos.x += this.velocity.x 
        this.pos.y += this.velocity.y
		 
		 let diffX = this.pos.x - this.anchor.x 
		 let diffY = this.pos.y - this.anchor.y
		 let dist =diffX*diffX + diffY*diffY
		 
            if(dist < 4.0){		  
		   		  			  
				  this.pos.x = this.anchor.x 				 
  		          this.pos.y = this.anchor.y 				 
				  
				  this.removeProp(ball_prop_restore_toAnchor)				  
				 				  
	          }
			  else {
				  
				      this.velocity.x = (this.anchor.x - this.pos.x)/10
          			  this.velocity.y = (this.anchor.y - this.pos.y)/10
				  				    
			  }	   
	   
   }
   */
   // canvas에 최종 출력되는 위치는 pos 
    updateRestoreToAnchor2(deltaT){
	   	   	   
  	     this.restoreUpdateCount++

	      if(this.restoreUpdateCount == 1){
			  
				return 
		   }
		   
		   
			   
		    this.restoreDelta.x = this.restoreDist.x/5
			this.restoreDist.x -= this.restoreDelta.x 
			
		    this.restoreDelta.y = this.restoreDist.y/5
			this.restoreDist.y -= this.restoreDelta.y
			
		//	gPrint(this.id + '-->restoreDelta ' + this.restoreDelta.x + ', '+ this.restoreDelta.y)
				 
			let absDistX = this.restoreDist.x 
			let absDistY = this.restoreDist.y
			
			if(absDistX <= 0){
				
				absDistX =-1*absDistX 
			}
			
			if(absDistY <= 0){
				
				absDistY =-1*absDistY 
			}
							 				 											 
            if(this.restoreUpdateCount == 5){		  
		   		  			  
				  this.pos.x = this.anchor.x 				 
  		          this.pos.y = this.anchor.y 			
				  
				  this.removeProp(ball_prop_restore_toAnchor)			
     			  gPrint(this.id + 'removeProp: ball_prop_restore_toAnchor')
        		 				  
	          }
			  else {
				  
				       this.pos.x += this.restoreDelta.x 				 
    		           this.pos.y += this.restoreDelta.y 			
				  				    
			  }	   
	   
   }
   
	
   proc_enemy_bullet_collideWith_player(){


           let refX = this.pos.x 
            let refY = this.pos.y 
	
			//100x100
			let minX = gClientW/2 -50 
			let maxX = minX + 100 
			let minY =  gPlayerRefY - 50 
			let maxY =  minY + 100 
			
			//minX,minY |---
			//               |
			//               |
			//-----------(maxx,maxy)
			
			if(refX >= minX && refX <= maxX &&
			   refY >= minY && refY <= maxY){				
         
		      setPlayerAct(act_damage)
			  
			  playSoundEffect(sound_cat_02)
				
			   return true 
			}						
		
		 return false
   }	   
	//enemy bullet이 방금 발사된 petball과 충돌할 경우  
	//target: move상태인 petBall 
	proc_enemy_bullet_collideWith_petBall(target){
														
			if( isPetBall(target) ) {
								
                 if(target.state == ballstate_move){								
									
					this.setState(ballstate_fallingDown)
					
					this.velocity.x = getRandomVal(-0.5, +0.5)
					this.velocity.y = getRandomVal(-0.5, -0.6)
					
					gPrint( 'enemyBullet(' + this.id +')----collide--> petBall(' + target.id+')')	
				
				    playSoundEffect(sound_cat_01)
					
					let event = new CustomEvent("post_ball_interact", {detail:{id:target.id} })
					document.dispatchEvent(event)		
					
					target.setState(ballstate_fallingDown)
				
	     			return 				

		       }

			}
			else {
								
			    gPrint(this.id + 'enemyBullet----collide--> not petBall(' + target.id+')')	
			
				
			}
						
	}
	
	
	//=================	
	// col_info 정반사 
	proc_collideWith_rock(rockBall, col_info){
		//rock과 충돌시에는 옆 petBall과 draw처리 안함 
											
	            gPrint('petBall' + this.id + 'collide_rock ' + rockBall.id + 'rockRscIdx: ' + rockBall.rscIdx) 
														
			  //
			   rockBall.hitEventT = gAppCurT

				rockBall.isHit = true 
			
				
				   if( rockBall.hasProp(ball_prop_reflect) ){
					   //breakable, reflect, reflect2
						 
						  if(this.rscIdx == r_defense_ball){

   						      this.proc_collideWith_reflectRock(rockBall, col_info , false)							  
						  }
						  else {

   						      this.proc_collideWith_reflectRock(rockBall, col_info , true)

                              let event = new CustomEvent("post_ball_interact", {detail:{id:this.id} })
							  document.dispatchEvent(event)							
							  
						  }
															 
						return 						
					 }
					  
					  
					  
					  
					  
					  //====================
					  //reflect 성질 없는 경우 				
                      //====================		
					  if(rockBall.state == ballstate_move_pattern){
                      //움직이는 돌과 충돌한 경우 
						

						   if(this.rscIdx == r_diamond){
							   
							   
						   }		
	     			    	//rockBall기준으로 이동해야 합니다. 
						 						 
						 
						  //updateDistJoint에서 update됨 
						  
			              rockBall.addProp(ball_prop_restore_toAnchor)
						  
						  this.addProp(ball_prop_updateAnchor)
						  this.addProp(ball_prop_not_draw)
						  
	 					  rockBall.setVelocity(this.velocity.x, this.velocity.y)	
						  rockBall.pos.x += this.velocity.x*20
						  rockBall.pos.y += this.velocity.y*20
						  	
					 	   //----	
                           rockBall.restoreDist.x = rockBall.anchor.x - rockBall.pos.x							
						   rockBall.restoreDist.y = rockBall.anchor.y - rockBall.pos.y
						   rockBall.restoreUpdateCount = 0
						   
						  
						   //----
							
						  	this.refBall_id = rockBall.id
							this.offsetPos.x = this.pos.x - rockBall.pos.x 
							this.offsetPos.y = this.pos.y - rockBall.pos.y 							
							gPrint(this.id + 'offsetPos.y ' + this.offsetPos.y)
												    
						  
					  } //movepattern 상태인 것과 충돌 끝 							  				 
				  
				  
				  	 let refDist = rockBall.radius + this.radius 						 
					  regDistJoint(rockBall.id, this.id, refDist)


                    if( rockBall.rscIdx ==  r_rock_float_anchor){
						
					     gPrint(this.id + '------>collide with float_anchor')							 
						 this.floatAnchorId = rockBall.id 						
					 }

				 
					 this.velocity.x = 0 
					 this.velocity.y = 0			
					 
					 this.isAnchored = true 
					 this.setState(ballstate_anchored)
					 
					 this.anchor.x = this.pos.x 
					 this.anchor.y = this.pos.y
												
					 //=================
					 //고정 
					 this.addProp(ball_prop_fixedToRock)
					 //==================
					 
					 let event = new CustomEvent("post_ball_interact", {detail:{id:this.id} })
					  document.dispatchEvent(event)	

			        //end rock 							  
		
	}
	
	//-----------------------------
	//for defenseBall 
	//col_info (from resolveCollision)
	//-------------------------------	
	proc_collideWith_reflectRock(rockB, col_info, isRemove){

              	if( this.hasProp(ball_prop_invincible) ){
					 					 
					 this.invincible_collideWith_reflectRock(rockB)
					 
					 return
				 }

                gPrint('proc_collideWith_reflectRock: rscIdx->' + rockB.rscIdx)

				 //respV1 이미 speed가 고려된 상태 
				 let respV1 = col_info.resV
				 //------------
				 
				 let curSpeed = getVecLength(this.velocity)
				 
				 if(curSpeed > 0.4){
					 
					 curSpeed = 0.4
				 }
				 
				 gPrint('reflectRock curSpeed ' + curSpeed) 
										 
				 //this의 속도의 반대방향의 방향벡터 구하기 
				 //speed가 고려되어 있지 않은 방향벡터
				 let respV2_info = get_ball_responseV_d1(this, rockB)
				 
				 
				 let speed = 0.3						 
				 let rePos = respV2_info.rePos 
				 
				 if(gNumRetry >= 2){
					 
					 speed = 0.25							 
				 }
				 
				 let respV2 = {x:0, y:0} 
				 
				 if(rockB.normalKind != normal_unknown ){
				                    
					//speed가 고려되어 있음 				
					respV2 =  get_reflectV_normal_vh(this, rockB, speed) 				
					 
				 }
				 else {
					 
					 gPrint('respV.x ' + respV2_info.respV.x)
					 					 
					 respV2.x =  respV2_info.respV.x*curSpeed
	 	     		 respV2.y =  respV2_info.respV.y*curSpeed
					 
				 }				 
				 				 
				  rockB.hitEventT = gAppCurT
				  rockB.isHit = true 
				
				
									 
				 //reflect와 충돌 
				 if(rockB.rscIdx == r_rock_float_anchor || rockB.rscIdx == r_rock_reflect 
				 || rockB.rscIdx == r_rock_reflect2 || rockB.rscIdx == r_rock_reflect3 
				 || rockB.rscIdx == r_rock_reflect4 || rockB.rscIdx == r_rock_reflect_invincible){
					 
					 	this.pos.x = rePos.x 
					    this.pos.y = rePos.y 
	 								 
						 playSoundNoteByRscIdx(rockB.rscIdx)

                    //반사되는 것과 움직이는 것은 충돌후 속도가 증가함									 									 
					 //petball이 움직이는 r2와 충돌 
					 if(rockB.state == ballstate_move_pattern ){


                           if(rockB.movePatternIdx == move_byTentacle){
							   
							   //monster처럼 아래 방향으로 빠르게 
							   
							  let newVel = getVelocity_attackToPaddle(speed)
							  this.velocity.x = newVel.x 
							  this.velocity.y = newVel.y 
							  
							  this.removeProp(ball_prop_attack_enemy)
                           	  this.addProp(ball_prop_attack_player)
							  //this.iSpriteIdx = 1 
							  //색깔 변경X
							  
						   }
						   else {

								this.velocity.x = respV2.x*1.05 
								this.velocity.y = respV2.y*1.05 
						   }

						 
					 }
					 else {
						 
						 
					
							 if(rockB.normalKind != normal_unknown  ){
								 
								 this.velocity.x = respV2.x*1.05 
								 this.velocity.y = respV2.y*1.05 
							 }
							 else {
							 
								 this.velocity.x = respV1.x
								 this.velocity.y = respV1.y
							 }
					
					 }
					 
				 }
				 else { // breakeable과 충돌
												 
												 
						 this.pos.x = rePos.x 
						 this.pos.y = rePos.y 
					 					   
						 this.velocity.x = respV1.x
						 this.velocity.y = respV1.y 
				 }
				 
				 
				 
				   if(rockB.rscIdx == r_rock_reflect || rockB.rscIdx == r_rock_breakable){
						 						 
						  if(isRemove){
						 
						 	this.setState(ballstate_fallingDown)			
						  }
						 
				   }
				   else {
					   
					   //reflect2는 반사 후 계속 이동시킴  
					   
				   }


				  //======================
				 // 후처리
				 //======================						 
				 if(rockB.rscIdx == r_rock_breakable ){
					//breakable 후처리 
				
						rockB.hp -= this.power
						
						if(rockB.hp <= 0){
							
							gUserScore += 3
							let textSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 3)							
							//gray
							textSpr.colorStr = "#c0c0c0"
														
							
							 rockB.isWaitForRemove = true
							 addDebrisEffect(rockB.pos.x, rockB.pos.y, 0)
							 
							 playSoundEffect(sound_broken)
							 
							 playSoundNote(sound_note_la)
							 
							 
							 beginEarthQuake()
							 
							 //명시적으로 아이템 드랍
							 if(rockB.post_rscIdx != r_none){
								 
								 if(gIsRetryStage == false ){
									 
									 let xp= rockB.pos.x , yp= rockB.pos.y										 
									 addGameCmd('post_rscIdx', {x:xp , y:yp, rscIdx: rockB.post_rscIdx} ) 
									 
								 }
							 }
							 else {
								 
									 //10% 가능성으로 item
									 let rand = getRandomVal(1, 100)						 
									 if(rand <= 10){
																				 
										let item_rIdx = getRandomItem()
																				 
										 let xp= rockB.pos.x , yp= rockB.pos.y										 
										 addGameCmd('post_rscIdx', {x:xp , y:yp, rscIdx: item_rIdx}  ) 											
										 										 
									 }		
										 								 
							 }
							 
							 
							
						}
						else {
							
							    gUserScore += 1
							    let textSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 1)
	                             textSpr.colorStr = "#c0c0c0"
								
														
							     playSoundNote(sound_note_pa)
								
								if(rockB.hp > 1 ){
									
									 rockB.iSpriteIdx = 1 

								}
								else if(rockB.hp <= 1){

									 rockB.iSpriteIdx = 2										
								}
							
							
						}
													
						// this.velocity.x = respV1.x 
						// this.velocity.y = respV1.y 
						
				 } //dreakable
				 else if(rockB.rscIdx == r_rock_reflect){
					 //일반 reflect후처리 
					     
										 						 
					     rockB.iSpriteIdx = 1						 
						 rockB.hp -= this.power

						 if(rockB.hp <= 0 ){
													
							this.changeRockToBreakable(rockB)
							
							gUserScore += 3 															
							let textSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 3)
							textSpr.colorStr = '#9DE1FA'		
							
						 }
						 else {
							 
							 gUserScore += 1
							 let textSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 1)
							  textSpr.colorStr = '#9DE1FA'							 
						 }
									
					
					 
				 }
				 else if( rockB.rscIdx == r_rock_reflect3 && (rockB.movePatternIdx != move_byTentacle) ){
					 
		 			    rockB.hp -= this.power
						
						if(rockB.hp <= 0){
						
                           addDebrisEffect(rockB.pos.x, rockB.pos.y, debris_reflect3)	
                           rockB.isWaitForRemove = true 			

//                          playSoundEffect(sound_broken)
                           playSoundNote(sound_note_broken)						  
							
						}
						else {
							
					       rockB.iSpriteIdx = 1	
						
						}

                     	 gUserScore += 1
						 let spr = addScoreSpr(rockB.pos.x, rockB.pos.y, 1)
						 spr.colorStr = '#FA0000'
											
					
				 }			 
				 else if( rockB.rscIdx== r_rock_reflect_invincible){
					 
					 	  rockB.iSpriteIdx = 1						 
						 // rockB.hp -= this.power
						 
			         	 //gUserScore += 1
						 //let spr = addScoreSpr(rockB.pos.x, rockB.pos.y, 1)
						 //spr.colorStr = '#A3F914'
				 }
				 else if(rockB.rscIdx == r_rock_reflect2  || rockB.rscIdx == r_rock_reflect3 || rockB.rscIdx == r_rock_reflect4){
					 //파괴X
					 
					    rockB.iSpriteIdx = 1						
						this.power += 0.5
					 					 										 
					 
				 }else if(rockB.rscIdx == r_rock_float_anchor){
					 
					 
					 	 rockB.isWaitForRemove = true
						 
						 if(rockB.post_rscIdx != -1){
							 
							 	 let xp= rockB.pos.x , yp= rockB.pos.y										 
							     addGameCmd('post_rscIdx', {x:xp , y:yp, rscIdx: rockB.post_rscIdx} ) 
							 
						 }
						 
					    
						 playSoundNote(sound_note_do)
				 
	 					 gUserScore += 1

                        let scoreSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 1)
                         scoreSpr.colorStr = '#FD9301'								
                       
  		         }
		
	}
	
	
	
	invincible_collideWith_reflectRock(rockB){
				 
         this.velocity.x *=1.05		 
         this.velocity.y *=1.05		 
        		
		 if(rockB.rscIdx == r_rock_float_anchor || rockB.rscIdx == r_rock_reflect || rockB.rscIdx == r_rock_reflect2 ){
		 
		           rockB.setState(ballstate_fallingDown)
		
                   playSoundNoteByRscIdx(rockB.rscIdx)


		 }
		 else if(rockB.rscIdx == r_rock_breakable) {
			 //breakable 
			 
					gUserScore += 3
					let textSpr = addScoreSpr(rockB.pos.x, rockB.pos.y, 3)							
					textSpr.colorStr = "#FD9301"												
					
					 rockB.isWaitForRemove = true
					 addDebrisEffect(rockB.pos.x, rockB.pos.y, 0)
					 
					 playSoundEffect(sound_broken)
					 
					 playSoundNote(sound_note_la)
					 
					 
					 beginEarthQuake()
					 
					 if(rockB.post_rscIdx != r_none){
						 
						 if(gNumRetry >=1  ){
							 
							 let xp= rockB.pos.x , yp= rockB.pos.y										 
							 addGameCmd('post_rscIdx', {x:xp , y:yp, rscIdx: rockB.post_rscIdx} ) 
							 
						 }
					}
			   			 
		 }

		 
	}




    changeRockToBreakable(targetRock){
		
		gPrint('changeRockToBreakable')
			
			//반사성질 없애기
			targetRock.rscIdx = r_rock_breakable
			
			targetRock.resetSprFrame()
			
	        targetRock.img = rock_img	
			
		   targetRock.addSprFrame(207, 308, 100, 100)
		   targetRock.addSprFrame(309, 308, 100, 100)
		   targetRock.addSprFrame(409, 308, 100, 100)
			
			targetRock.angle = getRandomVal(0, 180)

		    targetRock.hp = 5
			targetRock.hitCount = 0
					
			targetRock.useCustomSprIdx = true 
			targetRock.iSpriteIdx = 0
			
		
	}


  //================
   updateMove(){


   }	   
     
  //r_mon2는 직접 공격을 할 수 없으므로 proc_monster_damage에서 처리 
  proc_collideWith_monster(monBall, isKeepAlive=false){
	  
	  console.log('proc_collideWith_monster --begin')
	  
	  if( this.bounceCount >= 5){
		  
		  this.bounceCount = 5
	 }
	 
	   if(isKeepAlive== true){
		  		  
	  }
	  else {		  
		  
		 this.isWaitForRemove = true;		  
	  }
	 
	 //========================
	 //post_monsterDead가 두 번 호출되지 않도록 방어
	 if(monBall.actState == act_dead){
		 
		 
		 return 
	 }
	 //=========================
	 
	  
	  let power = 1 + this.bounceCount 
	  
	     
 	 monBall.hp -=  power

	  
      playSoundEffect(sound_match_02)
	  
	  
	  let refX = monBall.pos.x 	  
	  let refY = monBall.pos.y 
	  

	   let iPower = parseInt(power)	  
	   gUserScore  += iPower
	   
	   	 
		 
	  if(monBall.hp <= 0){
		  
	   	   gPrint('monBall dead')
	
	
		   post_monsterDead(monBall)

	  }
	  else {
		  
		  //============
	      //textSprite 
		  //============	  
	
		  
		  if(power >= 2){

                beginEarthQuake()			  
		  }
		  
		  monBall.setAct(act_damage)
		  
	  }

	  
	  addMonsterDamageTextSpr(refX, refY, iPower)
	  
	 //0.3초간 짧게 빨간 이펙트 한 번만 
	  addEffectSpr(refX, refY, 1, 150, 300)
			 
	  
	
  
	  
  }
   


   
   
   
//============   
 updateMove2(deltaT){
	 
	 if(this.state == ballstate_bigToNormal){
		 
	      if(this.userVal == 0){
		
	 	        let elapsT = gStageElapsT - this.userT 	  
				
			//	gPrint('gStageElapsT:  ' + gStageElapsT)
           
				if(elapsT > 2000){
					
					this.userVal = 1 	
                					
				}
						  
		  }
		  else if(this.userVal == 1){


			   let diffx = this.dstPos.x - this.pos.x 
			   let diffy = this.dstPos.y - this.pos.y 
		   
	  	       if(Math.abs(diffx) < 5 && Math.abs(diffy) < 5){
				
				  this.userVal = 2 
				
			   }
			   else {
				   
				 
                   let dispx = diffx / 10				 
	               let dispy = diffy / 10				 
				   
				   this.pos.x += dispx 
				   this.pos.y += dispy 

			   }
              
		  }
		  else if(this.userVal == 2){
			  
			    this.scale = 1.0
			  
			  	this.setState(ballstate_anchored)
			  
		  }
		  

		 
	 }
	 else if(this.state == ballstate_move_toDst){
		 
		 //너무 빨리 
		 //2초 동안 이동하기 
		 //let velocity.x = diffx/2000
		 if(this.isArriveDstPos == false){

			   let diffx = this.dstPos.x - this.pos.x 
			   let diffy = this.dstPos.y - this.pos.y 
			   
				   if(Math.abs(diffx) < 5 && Math.abs(diffy) < 5){
					   
					   this.isArriveDstPos = true 
					   this.isWaitForRemove = true 
					   
					
					   gPrint('ball: arriveDstPos')
				   
				   }
				   else {
					   
					  let dispx =  diffx/20
					  let dispy =  diffy/20 
					  
					  this.pos.x += dispx 
					  this.pos.y += dispy
				   }

		 }			 	 
		 
	 }
	  else if(this.state == ballstate_move_nextCollide){
	
	
	         this.pos.x +=  this.velocity.x             
		     this.pos.y +=  this.velocity.y
			 
			 
			 let diffX = this.pos.x - this.anchor.x 
			 let diffY = this.pos.y - this.anchor.y
			 let dist = Math.sqrt(diffX*diffX + diffY*diffY)
			 
			 if(dist >= 40){
				 
				 this.setState(ballstate_restore_toAnchor)
				 
			 }
			
		  
	  }
	  else if(this.state == ballstate_restore_toAnchor){
		  
		  
             this.pos.x +=  this.velocity.x             
		     this.pos.y +=  this.velocity.y
			 
			 let diffX = this.pos.x - this.anchor.x 
			 let diffY = this.pos.y - this.anchor.y
			 let dist = Math.sqrt(diffX*diffX + diffY*diffY)
			

            if(dist < 2.0){		  
		   		  
				   gPrint(this.id + '=>end ballstate_restore_toAnchor')
				  
				  this.pos.x = this.anchor.x 				 
  		          this.pos.y = this.anchor.y 				 
				  
                  this.printPosition()
  		          				  
				  this.setState(ballstate_anchored)
				 				  
	          }
			  else {
				  
				      this.velocity.x = (this.anchor.x - this.pos.x)/5
          			  this.velocity.y = (this.anchor.y - this.pos.y)/5
				  
				    
			  }
			  
	  }
	  else if(this.state == ballstate_anchored){
		  
		  		  
			
				  	  
				  
				  
		  
	  } 
	  else if(this.state == ballstate_move_byExtForce){
		 	
		 	 console.log('ballstate_move_byExtForce')		
				
	    	 this.pos.x +=  this.velocity.x*deltaT             
		     this.pos.y +=  this.velocity.y*deltaT
				 		
			 this.setState(ballstate_restore_toAnchor)

		
	  }
	  else if(this.state == ballstate_sleep ){
		  
		 		 
				  
	  }	  
	 else if(this.state == ballstate_move_toDrawBall){
		
        //자신을 끌어당기는 ball의 위치로 이동		
		
		let drawerBall = getBall(this.drawer_id)
		
		if(drawerBall == null){
		
		   console.log('drawerBall: ' +  this.drawer_id + '---> null')
            return 		
		}
       
 	    let dirX =  drawerBall.pos.x - this.pos.x 
	    let dirY =  drawerBall.pos.y - this.pos.y 
		
		let dirV = new Vec2(dirX, dirY)
		let dirV2 = dirV.unit()
		
		let refDist = drawerBall.radius + this.radius			
	    let dstPos = {x: (drawerBall.pos.x - dirV2.x*refDist), y: (drawerBall.pos.y - dirV2.y*refDist)}
	
		this.velocity.x = dirX/10 
		this.velocity.y = dirY/10 
		
		this.pos.x += this.velocity.x  
		this.pos.y += this.velocity.y  
		
		//draw 시작한 ball이 distjoint로 되어 있을 때 풀어주지 않으면 pos가 이동하지 않음 
        //-----> ballstate_move_toDrawBall인 것들은 distJoint업데이트 하지 말아야 		
		let dist = Math.sqrt(dirX*dirX + dirY*dirY)
		
			
		if(dist < refDist) {
			
			drawerBall.removeProp(ball_prop_drawer)
			this.removeProp(ball_prop_drawee)
						
			let  ancDiffX =  dstPos.x - this.lastAnchor.x 
			let  ancDiffY =  dstPos.y - this.lastAnchor.y 
			
			//-----------
			//draw직전위치와 중간으로 위치 보정하기 
  //          this.pos.x = dstPos.x
  //			this.pos.y = dstPos.y
 		    this.pos.x = this.lastAnchor.x + ancDiffX*0.7
			this.pos.y = this.lastAnchor.y + ancDiffY*0.7

			//-------------
			//anchor위치도 다시 설정
			this.setAnchor(this.pos.x, this.pos.y)
			//-------------						
 			console.log(this.id + '.end -ballstate_move_toDrawBall: ' + this.drawer_id + '<------' + this.id )
            this.printPosition()
			
			if(this.drawer_id < this.id ){
				
			   //A기준으로 this가  따라감 	
			   regDistJoint(this.drawer_id, this.id,  refDist )
				
			}
			else {

		    	regDistJoint(this.id, this.drawer_id, refDist )
								
			}
			

         	if(this.rscIdx  ==  drawerBall.rscIdx){
				
				 regMatchBall_id(this.id,this.drawer_id)
			 }
			 

			this.setState(ballstate_anchored)
			
			 let event = new CustomEvent("post_ball_interact", {detail:{id:this.id} })
			 document.dispatchEvent(event)
						 			
		}


				 
	 }
	
	if(this.state == ballstate_move_pattern){
		
	    this.movePattern(deltaT, this.movePatternIdx)	
		
	}
	
	if(this.state == ballstate_fallingDown){
		
		this.fallingDown(deltaT)
		
	}
	else if(this.state == ballstate_fallingDown2){
		
		//중력 가속도 적용 0.0 ~ 1.0 
		this.fallingDown(deltaT, 0.1)
		
		if( this.effectSpr !=null ){
							 
			 this.effectSpr.setPos(this.pos.x, this.pos.y)
		 }				
		 		
	}
	else if(this.state == ballstate_small_toDeath){
		
		this.smallToDeath(deltaT)
		
	}
 	
	 
 }	 

//-------------------

movePattern(deltaT, pattern_idx){
										
										
			if(this.angleSpeed > 0){				
				    
					//local_rotatio
					this.angleR += this.angleSpeed 
		     }

        			
			if(pattern_idx == move_circle){
		
		       this.proc_move_circle()
		
			}			
			else if(pattern_idx == move_rot){
				//제자리에서 회전만 
				
				
			}
			else if(pattern_idx == move_h){
								
				this.pos.x += this.patternVelocity.x*deltaT
				this.pos.y = this.anchor.y 
				
				if(this.isDebug){ 
				  this.printPosition()
				}
				
				let maxX = this.moveMax - this.radius
				let minX = this.moveMin + this.radius
				
					if(this.pos.x >  maxX){

                       this.patternVelocity.x = -1*this.patternVelocity.x
					   this.pos.x = maxX
					   
				}					
				else if (this.pos.x < minX){
					
                       this.patternVelocity.x = -1*this.patternVelocity.x 					
	 				   this.pos.x = minX
				}
				
							
					this.anchor.x = this.pos.x
					this.anchor.y = this.pos.y
									
			}	
			else if(pattern_idx == move_v ){
				
				this.pos.x = this.anchor.x 
            	this.pos.y += this.patternVelocity.y*deltaT
				
				if(this.isDebug){ 
				  this.printPosition()
				}
				
				let maxY = this.moveMax - this.radius
				let minY = this.moveMin + this.radius
				
				if(this.pos.y >  maxY){

				   this.patternVelocity.y = -1*this.patternVelocity.y
				   this.pos.xy= maxY
				   
			  }					
			  else if (this.pos.y < minY){
				
				   this.patternVelocity.y = -1*this.patternVelocity.y 					
				   this.pos.y = minY
			  }
			
							
					this.anchor.x = this.pos.x
					this.anchor.y = this.pos.y

				
			}
			else if(pattern_idx == move_byGroup){
				
	 			
		//	  gPrint(this.id + 'pos byGroup==>' +this.pos.x)
			
			  //gPrint(this.id + 'move_byGroup')
				
			}
	
	}
   
  proc_move_circle(){
  
		//최소: this.moveMax
		//최대: this.moveMin
	
         //반지름 고정: 80					 
		 
		 let r 
		 
		 if(this.customRadius !=0 ){

           r = this.customRadius			 
			 
		 }
		 else {
		 
		 
			 if(this.level == 1){
					  
				   r = move_c_radius_short				 
			 }
			 else {
				 
				  r = move_c_radius_level_2			
			 }
		 
		 }		 
		 
		 
		if(this.moveMin != this.moveMax){

           //  gPrint('circleMoveAngle: ' +  this.circleMoveAngle) 

             	//----clamp----
  		       this.circleMoveAngle += this.patternVelocity.x	

               if(this.circleMoveAngle > this.moveMax){
						 
				   this.patternVelocity.x = -1*this.patternVelocity.x					 
				   this.circleMoveAngle = this.moveMax 
						 
		       }else if(this.circleMoveAngle < this.moveMin) {
			  
				   this.patternVelocity.x = -1*this.patternVelocity.x					 
				   this.circleMoveAngle = this.moveMin
			  
		       }
		  
		}
		else {
		
				if(this.level == 1){

				   this.circleMoveAngle += move_c_speed_level_1		

				}
				else {
														
					this.circleMoveAngle += move_c_speed_level_2			
				}
			
		}
		 
		
		
		let angleR = this.circleMoveAngle*(Math.PI/180)
		
		let x =  Math.cos(angleR)*r - Math.sin(angleR)*0 + this.circleCenter.x 	
		let y = Math.sin(angleR)*r  + Math.cos(angleR)*0 + this.circleCenter.y 
			
		this.pos.x = x 
		this.pos.y = y 
	
		this.anchor.x = x
		this.anchor.y = y


  }
  
  
  fallingDown(deltaT, weight=1.0){

	this.velocity.y += worldGravity*weight*deltaT
	
	this.pos.x += this.velocity.x*deltaT 
	this.pos.y += this.velocity.y*deltaT 
	
//	console.log(this.id + '==>fallingdown pos' + this.pos.x + ',' + this.pos.y)
	
	let maxY = gClientH + 10 

    if(this.pos.y >=  maxY){
		
		this.isWaitForRemove = true 
		//console.log(this.id + '==>isWaitForRemove=true')
	}		
	
}


   smallToDeath(deltaT){
	   	
	this.radius = this.radius*0.8
	
	if(this.radius <= 5){
		
		this.isWaitForRemove = true 
	}		

	   
  }



moveToDrawTarget(){
	
	
	
}


//draw대상 contact후
drawNextBall(peer){
	
  //let diffX = this.pos.x - peer.pos.x  
  //let diffY = this.pos.y - peer.pos.y  
		
}

//================
// (1) (3을 draw하면 안됨)
//   (2)
//     (3)
//자신이 draw할 수 있는 ball을 찾기 
getDrawTarget(){
	
//	gPrint(this.id + "getDrawTarget")

   let refDist = 0	
   for(let idx=0	; idx < gBalls.length ; idx++){
        
        let b = gBalls[idx]
        
		if(b.rscIdx == rscIdx_rock_01){
			
             continue
		}			
		
		if( b.hasProp(ball_prop_fixed) ){
			
			continue;
		}
		
		if(b.hasProp(ball_prop_not_draw) ){
			
			continue 
		}
				
		//움직이는 돌에 연결된 것들도 drawer에서 제외 
		
		  	    
		if(b.id == this.id ){
			continue 
		}
		
		//이동중인 rock 
		if(b.state == ballstate_move || b.state == ballstate_fallingDown){
		
            continue 		
		}
		
		//-------------
		//이미 나와 contact인 경우 
		if( this.isMyLinkBall(b.id) == true){
			
			continue;
		}
		

        if(isExistIntersectPetBall(this, b) == true){
			
		     continue;	
		 }
			          		 
        let diffX =this.pos.x - b.pos.x
        if(diffX < 0) diffX = -1*diffX 
	   
        let diffY =this.pos.y - b.pos.y
        if(diffY < 0) diffY = -1*diffY 
			  
         refDist = b.radius + this.radius + b.radius*0.8
		 
		 let dist = Math.sqrt(diffX*diffX + diffY*diffY)
		 
		 
		 //대상이 최근 발사된 것인 경우 
		 if(b.id == gLatestBall_id){
			 
			  gPrint(this.id + '<------------' + b.id)
			  gPrint('dist LatestBall: ' + dist + ', refDist: ' + refDist)
		 }
		
			  
		if( (diffX < refDist) && (diffY < refDist) ){
			
           return b 
		}
        else {


		}			
		
			  	  
   }
	

	return null 
	
}


 //nextBall: peer2 
 move_TolinkNextBall(peer1, nextBall){
	 
	 let diffX = nextBall.pos.x - this.pos.x 
	 let diffY = nextBall.pos.y - this.pos.y 
	 	 
	 let velocity = {x: diffX, y: diffY}	

      velocity.x = diffX/10
      velocity.y = diffY/10
	 
     this.pos.x += velocity.x 	 
     this.pos.y += velocity.y 	 
	 
    //reposition peer1 
	// this----peer1---->nextBall	

    let dirV = new Vec2(this.pos.x -peer1.pos.x  , this.pos.y - peer1.pos.y )
	let dirV2 = dirV.unit()
	
	//보정하기 
    let refDist = this.radius + peer1.radius     
	
	this.pos.x = peer1.pos.x + dirV2.x*refDist 
	this.pos.y = peer1.pos.y + dirV2.y*refDist 

		
 }



 //==================
   getNearestCollidableBall(){
	   
    let collidableBalls=[]	   
	   
	 let ray = {x: this.velocity.x*50, y: this.velocity.y*50}
     	 
	 let normV = vec2PerpendicularCCW(ray)
	 normV = normV.unit()
	 
	 console.log('normV: ' + normV.x + ', ' + normV.y)
	 console.log('rayV: ' + ray.x + ', ' + ray.y)
	 
	 let dot = 0
	 
	 let refV = {x:0, y:0}
	 let refDist
	 	  
    for(let i=0; i< gBalls.length ; i++){
		
			let b = gBalls[i]
		
			if(b==this || b.rscIdx == rscIdx_rock_01){
					
				  continue	
			}
			
			if(b.state == ballstate_move){
				
				continue;
			}
	
		  refV.x = b.pos.x - this.pos.x  	
		  refV.y = b.pos.y - this.pos.y
		  
		  dot = normV.x*refV.x + normV.y*refV.y  

		  console.log( 'rayCast: ' + b.id + '.dot ' + dot)  	
		  if (dot < 0){

			  continue;
		  }
		  
		  refDist = b.radius + this.radius
		 		  
		  if(dot <= refDist){
			  
			  console.log('rayCast: intersect-----> ' + b.id + 'dist ' + dot)  
			  
			  collidableBalls.push(b.id)
			  
		  }
		  
	  	
	 	   
    }
 	 
     return collidableBalls
	 
	   
   }
   
   
   //==================
   //
   //
   //==================
   	proc_defenseBall_collideWith_monster(peerB, col_info){
		
		console.log('proc_defenseBall_collideWith_monster')
		
		if( this.hasProp(ball_prop_attack_enemy)  == false){
			
			return false 			
		}

		let monB = peerB 								
		
		//==============================
		//ball 충돌후 사라지지 않음
		this.proc_collideWith_monster(monB, true)
		//==============================
						
		this.removeProp(ball_prop_attack_enemy)
		this.addProp(ball_prop_attack_player)
		
		//===============
		//색깔 변경X (monsterBullet과 혼동됨)
	    // this.iSpriteIdx = 1
		//==============
		
		if(monB.hp <= 0){								
			
			//monB가 없어진 후에도 item을 획득을 위해 defenseBall 유지 
			
			

		  return			
		}
		
		
			let speed = getVecLength(this.velocity)
			
			let nVelocity = getVelocity_attackToPaddle(speed)			
		    this.setVelocity(nVelocity.x, nVelocity.y)
						

			 
		 return true 
	}//end of function
	
   
  
  
 
   
   
   printPosition(){
	   
	   let posX = this.pos.x.toFixed(2)
	   
	   gPrint(this.id + '=>pos: ' + posX + ',' + this.pos.y.toFixed(2) + '(anchor:' + this.anchor.x.toFixed(2) +',' +this.anchor.y.toFixed(2)  +')') 
	   
   }
   
    printVelocity(){
	   
	   gPrint( '=>vel: ' + this.velocity.x + ', ' + this.velocity.y) 
	   
   }
   
/*
const ballstate_move = 0
const ballstate_link = 1 
const ballstate_anchored = 1 
const ballstate_move_byExtForce = 2 
const ballstate_sleep = 3
*/
setState(state){
		
		let stateDispName = '' 
		switch(state){
	
	    case ballstate_anchored: 
			stateDispName = 'ballstate_anchored'
 		break;
		
		case ballstate_move_byExtForce: 
			stateDispName = 'ballstate_move_byExtForce'	
           console.log('id ' + this.id + ':=> stateBegin--->' + stateDispName)				
          break;		
		
		case ballstate_restore_toAnchor:
			stateDispName = 'ballstate_restore_toAnchor'	 
            console.log('id ' + this.id + ':=> stateBegin--->' + stateDispName)			
		break 
		
		case ballstate_sleep: 
			stateDispName = 'ballstate_sleep'		
          break;		
		  
	    case ballstate_move_toDrawBall:
		    stateDispName = 'ballstate_move_toDrawBall'		
          break;   	  
		
    	  
		  /*
 	    case ballstate_fallingDown:
		    stateDispName = 'ballstate_fallingDown'		
         break;   	  
         */
		
		 default:   
		    stateDispName = '----'		
		  
		}	
	
     		
		this.state =state 
		
	}

	
	draw(ctx){
		
		
		if(this.img == null || this.img.complete == false){
			
			return 
		}
		
				
		let size = this.radius*2
		
		let cx = this.pos.x 
		let cy = this.pos.y 
		
		
		if(gAppSubstate == playSubstate_stageScene){
		  
            cy -= spaceScene_yOffs 		  
		}		
		else {
			
		}
		
		
		let hSize = size/2


		if(gAppSubstate == playSubstate_stageScene){
			
			 ctx.translate(cx, cy) 
		}
		else {

             ctx.translate(cx, cy) 	
					
		}
		
		
		
		ctx.rotate(this.angleR); 		
		
    						
        if( this.rscIdx == rscIdx_tiger){							
				
			if( (gAppCurT - this.frameLastT) >= 2000){
	
 	             this.iSpriteIdx++;			
				 this.iSpriteIdx = this.iSpriteIdx%2				
                 this.frameLastT	= gAppCurT			 
 			}				
									
			let srcX = this.iSpriteIdx*128  			
			ctx.drawImage(this.img, srcX, 0, 128, 128, -size/2, -size/2, size, size)			
			//ctx.drawImage(this.img, -hSize, -hSize, size, size)
		}
		else {
			
			if(this.useSprite){
								
				this.drawSprite(ctx)
			  
			} //end useSprite
			else {
				
				if(isEarthQuake){
					
					  let ranX = getRandomVal(-5, 5)
										
					  ctx.drawImage(this.img, -hSize+ranX, -hSize, size, size)
				}
				else {
				
	           	     ctx.drawImage(this.img, -hSize, -hSize, size, size)
				}
				
				
			}
			
		}

		
		 ctx.rotate(-this.angleR);
	     ctx.translate(-cx, -cy) 	
		 
	 

	}
	
	
	drawSprite(ctx){
		
			let size = this.radius*2
			let cx = this.pos.x
			let cy = this.pos.y 
			
			let hSize = size/2
												
				  if(this.ai != null){
					  //ai에서 spriteIdx관리
					  
										  
				  }
				  else  if(this.numSprFrame > 1){
					  
					  if(this.useCustomSprIdx == false){
						  
						  //자동 frame 진행
						    if( (gAppCurT - this.frameLastT) >= 2000){
				
								 this.iSpriteIdx++;			
								 this.iSpriteIdx = this.iSpriteIdx%this.numSprFrame		
								 this.frameLastT	= gAppCurT			 
						    }									  
					   }
				  }
				  
				  
					  
				   let frameIdx = this.iSpriteIdx											 			     
				   let  frame = this.sprFrames[frameIdx]								
				
				   let sX=frame.x , sY=frame.y
				   let sW = frame.w, sH = frame.h  
				  
				  
				  let sizeOff = 0
				  
				  if(this.rscIdx == r_mon1){
					 
					 if(frameIdx == 1){
                            sizeOff = 10
			            }
					 
				  }
				  
	
	              if(isEarthQuake){
					    
						let randY = 0//bg_offsetX
						let randX = 0//bg_offsetY
                      
	                   ctx.drawImage(this.img, sX, sY, sW, sH, -hSize+randX, -hSize+randY, size+sizeOff, size+sizeOff)

				   }
				   else {
				   
                       ctx.drawImage(this.img, sX, sY, sW, sH, -hSize, -hSize, size+sizeOff, size+sizeOff)
		
				   }
		
	}
	
	
	
		
}

